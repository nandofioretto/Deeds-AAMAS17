//
// Created by Ferdinando Fioretto on 1/20/16.
//

#ifndef TESTCPLEX_CPLEXSOLVERFULL_H
#define TESTCPLEX_CPLEXSOLVERFULL_H

#include "Solver.h"
#include "CplexSolverQP.h"

class CplexSolverQP : public Solver {
public:
    CplexSolverQP(Problem& p) :
    Solver(p)
    { }

    void iSolve(bool print=false);

};


#endif //TESTCPLEX_CPLEXSOLVERFULL_H
