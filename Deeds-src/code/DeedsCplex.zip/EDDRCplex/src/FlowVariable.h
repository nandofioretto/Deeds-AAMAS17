//
// Created by Ferdinando Fioretto on 1/19/16.
//

#ifndef TESTCPLEX_FLOWVARIABLE_H
#define TESTCPLEX_FLOWVARIABLE_H


#include <complex>
#include <vector>

class FlowVariable {

public:
    typedef FlowVariable* ptr;

    FlowVariable(int busTopID, int busZID, double min, double max, double resistance, double reactance, bool outgoing)
            : busTopID(busTopID), busZID(busZID), min(min), max(max), outgoing(outgoing)
    {
        values.resize(100, 0);
        impedance = std::complex<double>(resistance, reactance);
    }

    void resetValues() {
        for (int i=0; i<values.size(); i++)
            values[i] = 0;
    }

    double getMin() const {
        return min;
    }

    double getMax() const {
        return max;
    }

    double getResistance() const {
        return impedance.real();
    }

    double getReactance() const {
        return impedance.imag();
    }

    const std::complex<double> &getImpedance() const {
        return impedance;
    }

    int getBusTopID() const {
        return busTopID;
    }

    int getBusZID() const {
        return busZID;
    }

    std::vector<double> getValues() const {
        return values;
    }

    double getValue(int t) const {
        return values[t];
    }

    void setValue(double value, int t) {
        FlowVariable::values[t] = value;
    }

    bool isViolated(int t) {
        return (std::abs(values[t]) > max);
    }

    void setOutgoing(bool value=true) {
        outgoing = value;
    }

    bool isIncoming() const {
        return !outgoing;
    }

    bool isOutgoing() const {
        return outgoing;
    }

    const std::vector<double> &getShiftFactors() const {
        return shiftFactors;
    }

    void setShiftFactors(const std::vector<double> &shiftFactors) {
        FlowVariable::shiftFactors = shiftFactors;
    }

    std::string to_string() const {
        return "";
//        return "Flow: " + string_utils::to_string(busTopID)
//               + " -> " + string_utils::to_string(busZID)
//               + " [" + string_utils::to_string(min) + ", "
//               + string_utils::to_string(max) + "] "
//               + "(" + string_utils::to_string(impedance.real())
//               + " + j" + string_utils::to_string(impedance.imag()) + ")";
    }

private:
    double min, max;
    // Z = R + jX, Resistance (R) + Reactance (X) all measured in Ohms (j = sqrt(-1))
    std::complex<double> impedance;
    int busTopID, busZID;
    bool outgoing; // true = outgoing flow; false = incoming flow;
    std::vector<double> values; // size  = HORIZON

    // The shift Factor row of the C-matrix associated to this line flow.
    // Contains the multipliers for the active generators, except the slack bus.
    std::vector<double> shiftFactors;
};

#endif //TESTCPLEX_FLOWVARIABLE_H
