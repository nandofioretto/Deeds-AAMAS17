//
// Created by Ferdinando Fioretto on 1/21/16.
//

#include <ilcplex/ilocplex.h>
#include "Solver.h"

ILOSTLBEGIN


void Solver::printSolution(IloCplex& cplex, IloEnv& env) {
    try {
        if (cplex.getStatus() == IloAlgorithm::Infeasible)
            env.out() << "No Solution" << endl;

        env.out() << "Solution status: " << cplex.getStatus() << endl;

        // Print results
        env.out() << "Cost: " << cplex.getObjValue() << endl;

        for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon()); t++) {
            int t0 = t - currTime;

            float pgen = 0, pload = 0;
            env.out() << "TIME: " << t << endl;

            for (auto &var : genVariables[t0]) {
                env.out() << var.getName() << ": " << cplex.getValue(var) << endl;
                pgen += cplex.getValue(var);
            }
            for (auto &var : loadVariables[t0]) {
                env.out() << var.getName() << ": " << cplex.getValue(var) << endl;
                pload += cplex.getValue(var);
            }
#ifdef VERBOSE
            for (auto &var : flowVariables[t0]) {
                env.out() << var.getName() << ": " << cplex.getValue(var) << endl;
            }
#endif

            std::cout << "Total Power generated: " << pgen << "\n";
            std::cout << "Total Loads generated: " << pload << "\n";
        }
    }
    catch (IloException& ex) {
        cerr << "Error: " << ex << endl;
    }
    catch (...) {
        cerr << "Error" << endl;
    }
}


void Solver::saveSolution(IloCplex& cplex, IloEnv& env) {
    try {
        if (cplex.getStatus() == IloAlgorithm::Infeasible) {
            env.out() << "No Solution" << endl;
            return;
        }

        for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon()); t++) {
            int t0 = t - currTime;
            for (int i = 0; i < genVariables[t0].size(); i++) {
                auto& iloVar = genVariables[t0][i];
                mapGenVar[t0][i]->setValue(cplex.getValue(iloVar));
            }
            for (int i = 0; i < loadVariables[t0].size(); i++) {
                auto& iloVar = loadVariables[t0][i];
                mapLoadVar[t0][i]->setValue(cplex.getValue(iloVar));
            }
            for (int i = 0; i < flowVariables[t0].size(); i++) {
                auto& iloVar = flowVariables[t0][i];
                mapFlowVar[t0][i]->setValue(cplex.getValue(iloVar), t);
            }
        }
    }
    catch (IloException& ex) {
        cerr << "Error: " << ex << endl;
    }
    catch (...) {
        cerr << "Error" << endl;
    }
}