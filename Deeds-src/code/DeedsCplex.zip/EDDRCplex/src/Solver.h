//
// Created by Ferdinando Fioretto on 1/19/16.
//

#ifndef TESTCPLEX_SOLVER_H
#define TESTCPLEX_SOLVER_H

#include <ilcplex/ilocplex.h>
#include <vector>
#include "Problem.h"

class Solver {
public:
    Solver(Problem& p) :
            problem(&p),
            currTime(0)
    {
    }

    void solve(const int optH, bool print=false) {
        optHorizon = optH;
        while (currTime < problem->getHorizon()) {
            initialize(optHorizon);
            iSolve(print);
            clear();
            currTime += optHorizon;
        }
    }

    virtual void iSolve(bool print=false) = 0;

    void clear() {
        for (auto v : genVariables) v.clear();
        genVariables.clear();
        for (auto v : loadVariables) v.clear();
        loadVariables.clear();
        for (auto v : flowVariables) v.clear();
        flowVariables.clear();
        for (auto v : boolFlowVariables) v.clear();
        boolFlowVariables.clear();

        for (auto v : mapGenVar) v.clear();
        mapGenVar.clear();
        for (auto v : mapLoadVar) v.clear();
        mapLoadVar.clear();
        for (auto v: mapFlowVar) v.clear();
        mapFlowVar.clear();

        for (auto v : mapIloGenIdx) v.clear();
        mapIloGenIdx.clear();
        for (auto v : mapIloLoadIdx) v.clear();
        mapIloLoadIdx.clear();
        for (auto v : mapIloFlowIdx) v.clear();
        mapIloFlowIdx.clear();

        for (auto v : mapIloGenLoad) v.clear();
        mapIloGenLoad.clear();
    }

    void initialize(const int optH) {
        optHorizon = optH;

        genVariables.resize(problem->getHorizon());
        loadVariables.resize(problem->getHorizon());
        flowVariables.resize(problem->getHorizon());
        boolFlowVariables.resize(problem->getHorizon());

        mapGenVar.resize(problem->getHorizon());
        mapLoadVar.resize(problem->getHorizon());
        mapFlowVar.resize(problem->getHorizon());

        mapIloGenIdx.resize(problem->getHorizon());
        mapIloLoadIdx.resize(problem->getHorizon());
        mapIloFlowIdx.resize(problem->getHorizon());

        mapIloGenLoad.resize(problem->getHorizon());
    }

    int getCurrTime() const {
        return currTime;
    }

    void incrCurrTime() {
        Solver::currTime++;
    }

    void printSolution(IloCplex& cplex, IloEnv& env);

    void saveSolution(IloCplex& cplex, IloEnv& env);

protected:
    Problem::ptr problem;
    int currTime;
    int optHorizon;

    // Bus Var = genVar - LoadVar (can be 0 to 0)
    std::vector<std::vector<IloNumVar>> genVariables;
    std::vector<std::vector<IloNumVar>> loadVariables;
    std::vector<std::vector<IloNumVar>> flowVariables;
    std::vector<std::vector<IloNumVar>> boolFlowVariables;

    std::vector<std::map<GeneratorVariable*, int>> mapIloGenIdx;
    std::vector<std::map<LoadVariable*, int>>      mapIloLoadIdx;
    std::vector<std::map<FlowVariable*, int>>      mapIloFlowIdx;

    std::vector<std::map<int, GeneratorVariable*>> mapGenVar;
    std::vector<std::map<int, LoadVariable*>>      mapLoadVar;
    std::vector<std::map<int, FlowVariable*>>      mapFlowVar;

    // Key: busIdx  Value:  <gen idx, load idx> where idx is the position of the arrays gen/load-Variables
    std::vector<std::map<int, std::pair<int,int>>> mapIloGenLoad;

};


#endif //TESTCPLEX_SOLVER_H
