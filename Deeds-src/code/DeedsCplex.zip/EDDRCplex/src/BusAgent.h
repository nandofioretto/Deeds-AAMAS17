//
// Created by Ferdinando Fioretto on 1/19/16.
//

#ifndef TESTCPLEX_BUS_H
#define TESTCPLEX_BUS_H

#include <complex>
#include <vector>
#include <stdexcept>
#include "FlowVariable.h"
#include "GeneratorVariable.h"
#include "LoadVariable.h"

class BusAgent {

public:



public:
    typedef BusAgent* ptr;
    BusAgent() { }


    BusAgent(int busID, bool dispatchable=true, bool slackBus=false, bool referenceBus=false)
            : busID(busID), dispatchable(dispatchable), slackBus(slackBus), referenceBus(referenceBus),
              generator(false), load(false)
    { }

    void addLoad(LoadVariable::ptr load) {
        loadVariables.push_back(load);
    }

    void addGenerator(GeneratorVariable::ptr generator) {
        generatorVariables.push_back(generator);
    }

    void addNeighbor(BusAgent::ptr bus, FlowVariable::ptr flow) {
        if (BusAgent::getBusID() != flow->getBusTopID() || bus->getBusID() != flow->getBusZID())
            throw(std::runtime_error("Flow Constraint Top Bus not matching"));

        neighborsBuses.push_back(bus);
        flowVariables.push_back(flow);
    }

    int getNbBusNeighbors() const {
        return neighborsBuses.size();
    }

    BusAgent::ptr getBusNeighbor(int i) {
        return neighborsBuses[i];
    }

    int getBusID() const {
        return busID;
    }

    const std::string &getBusName() const {
        return busName;
    }

    const std::vector<double> &getAdmittanceRow() const {
        return admittanceRow;
    }

    const std::vector<ptr> &getNeighborsBuses() const {
        return neighborsBuses;
    }

    const std::vector<LoadVariable::ptr> &getLoadVariables() const {
        return loadVariables;
    }

    const LoadVariable::ptr& getLoadVariable(int time) const {
        return loadVariables[time];
    }

    const std::vector<GeneratorVariable::ptr> &getGeneratorVariables() const {
        return generatorVariables;
    }

    const GeneratorVariable::ptr& getGeneratorVariable(int time) const {
        return generatorVariables[time];
    }

    const std::vector<FlowVariable::ptr> &getFlowVariables() const {
        return flowVariables;
    }

    bool isDispatchable() const {
        return dispatchable;
    }

    bool isSlackBus() const {
        return slackBus;
    }

    bool isReferenceBus() const {
        return referenceBus;
    }

    void createAdmittanceMatrixRow(int nBuses) {

        admittanceRow.resize(nBuses, 0.0);

        for (int i = 0; i < BusAgent::getNbBusNeighbors(); i++) {
            auto flow = flowVariables[i];
            int iID = flow->getBusTopID();  // this agent;
            int jID = flow->getBusZID();    // other agent;

            std::complex<double> admittance_ij = 1.0 / flow->getImpedance(); // y_ij

            // off-diagonal terms Yij = negative line admittance between i and j bus.
            admittanceRow[jID] = -admittance_ij.imag();

            // diagonal Term: Yii = sum of all connected line admittances to this bus.
            admittanceRow[iID] += admittance_ij.imag();
        }
    }


    const std::vector<double> &getShiftFactors() const {
        return shiftFactors;
    }

    double getShiftFactor(int i) const {
        return shiftFactors[i];
    }

    void setShiftFactors(const std::vector<double> &shiftFactors) {
        BusAgent::shiftFactors = shiftFactors;
    }


    power_t getInitialPowerInjected() const {
        return initialPowerInjected;
    }

    void setInitialPowerInjected(power_t initialPowerInjected) {
        BusAgent::initialPowerInjected = initialPowerInjected;
    }

    power_t getInitialPowerWithdrawn() const {
        return initialPowerWithdrawn;
    }

    void setInitialPowerWithdrawn(power_t initialPowerWithdrawn) {
        BusAgent::initialPowerWithdrawn = initialPowerWithdrawn;
    }


    bool isLoad() const {
        return load;
    }

    void setLoad(bool isLoad=true) {
        BusAgent::load = isLoad;
    }

    bool isGenerator() const {
        return generator;
    }

    void setGenerator(bool isGenerator=true) {
        BusAgent::generator = isGenerator;
    }

    std::string to_string() const {
        return "";
//        std::string ret = "Bus " + string_utils::to_string(busID);
//        if (dispatchable) ret += " dispatchable ";
//        if (slackBus) ret += " slack ";
//        ret += "\n";
//        for (auto load : loadVariables)
//            ret += "\t" + load->to_string() + "\n";
//
//        for (auto generator : generatorVariables)
//            ret += "\t" + generator->to_string() + "\n";
//
//        for (auto line : flowVariables)
//            ret += "\t" + line->to_string() + "\n";
//
//        ret += "B_" + string_utils::to_string(busID) + ": ";
//
//        for (auto y : admittanceRow)
//            ret += string_utils::to_string(y) + " ";
//
//        ret += "\n K_" + string_utils::to_string(busID) + ": ";
//        for (auto s : shiftFactors)
//            ret += string_utils::to_string(s) + " ";
//
//        return ret;
    }

protected:
    int busID;
    std::string busName;
    bool dispatchable;
    bool slackBus;
    bool referenceBus; // known angles
    bool generator;
    bool load;

    power_t initialPowerInjected;
    power_t initialPowerWithdrawn;


    std::vector<BusAgent::ptr> neighborsBuses;
    std::vector<LoadVariable::ptr> loadVariables;
    std::vector<GeneratorVariable::ptr> generatorVariables;
    std::vector<FlowVariable::ptr> flowVariables; // flow (i,j) with i=Tap agent.
    std::vector<double> admittanceRow; // the row of the admittance matrix associated to this agent.

    // Todo: Get all topology with flowVariables ID, link flowVariables to Problem Class
    // The shift Factor column of the C-matrix associated to this bus.
    // Contains the multipliers for the flows, affected by the net power output of this bus.
    std::vector<double> shiftFactors;
};


#endif //TESTCPLEX_BUS_H
