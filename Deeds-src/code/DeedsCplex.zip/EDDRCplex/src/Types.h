//
// Created by Ferdinando Fioretto on 11/7/15.
//

#ifndef D_AGC_DR_TYPES_H
#define D_AGC_DR_TYPES_H


typedef double power_t;
typedef double flow_t;
typedef double angle_t;
typedef double cost_t;


#endif //D_AGC_DR_TYPES_H
