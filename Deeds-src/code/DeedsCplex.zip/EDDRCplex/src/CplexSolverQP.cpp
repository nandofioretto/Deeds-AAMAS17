//
// Created by Ferdinando Fioretto on 1/20/16.
//

#include "CplexSolverQP.h"
#include "utils.h"
#include <ilcplex/ilocplex.h>

ILOSTLBEGIN
#define SIMULINK_L
#define SIMULINK_G

#define RAMP_CONSTRAINT
#define FLOW_CONSTRAINT
//#define DC_CONSTRAINT
void CplexSolverQP::iSolve(bool print) {

    if (print) {
        std::cout << "====================================================\n";
        std::cout << "Solving from time " << currTime << " to Time " <<
        min(currTime + optHorizon, problem->getHorizon())
        << "\n";
        std::cout << "====================================================\n";
    }

    IloEnv env;

    try {
        std::vector<IloExpr> gCostExprs(optHorizon, env);
        std::vector<IloExpr> lCostExprs(optHorizon, env);

        std::map<int, BusAgent::ptr> mapGenBus;

        // Model - add objective and constraints
        IloModel model(env);

        for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon()); t++) {
            int t0 = t - currTime;
            auto totLoad = 0;
            auto totGen  = 0;
            for (auto& kv : problem->getPowerNetwork()) {

                bool dispatchable = kv.second->isDispatchable();
                auto gen_t = kv.second->getGeneratorVariable(t);
                auto load_t = kv.second->getLoadVariable(t);
                int busId  = kv.first;

                // Generator Variable Include Bounds
                auto minGen = gen_t->getMin();
                auto maxGen = gen_t->getMax();
                std::string genName = "gen_"+utils::to_string(busId)+"["+utils::to_string(t)+"]";
                IloNumVar gvar(env, minGen, maxGen, ILOFLOAT, genName.c_str());

                // Load Variable Include Bounds
                auto pred = load_t->getPredicted();
                auto minLoad = dispatchable ? load_t->getMin() : load_t->getPredicted();
                //  auto minLoad = dispatchable ? /*load_t->getMin()*/pred - sqrt(pred) : pred;
                auto maxLoad = load_t->getPredicted();
                std::string loadName = "load_"+utils::to_string(busId)+"["+utils::to_string(t)+"]";
                IloNumVar lvar(env, minLoad, maxLoad, ILOFLOAT, loadName.c_str());


                int iloGenIdx = (gen_t->getMax() > 0) ? genVariables[t0].size() : -1;
                int iloLoadIdx = (load_t->getMax() > 0) ? loadVariables[t0].size() : -1;

                // Cost Generator
                if (gen_t->getMax() > 0) {
                    mapGenBus[iloGenIdx] = kv.second;

                    genVariables[t0].push_back(gvar);
                    gCostExprs[t0] += gvar * gen_t->getAlpha();                  // linear
                    gCostExprs[t0] += IloPower(gvar, 2) * gen_t->getBeta();      // quadratic
                    // gCostExprs[t0] += IloAbs(gen->getEpsilon() * IloSin(gen->getPhi()
                    //          * (gen->getMin() - gvar) ));                        // non-convex

                    mapIloGenIdx[t0][gen_t] = iloGenIdx;
                    mapGenVar[t0][iloGenIdx] = gen_t;
#ifdef SIMULINK_G
                    if (t == 0) {
                        // Special case for simulator:
                        if (busId != 1) {
                            model.add(gvar == kv.second->getInitialPowerInjected());
                            totGen += kv.second->getInitialPowerInjected();
                        }
                    }
#endif
                }

                // Cost Load
                if (load_t->getMax() > 0) {
                    loadVariables[t0].push_back(lvar);
                    lCostExprs[t0] += lvar * load_t->getAlpha();                 // linear
                    //lCostExprs[t0] += IloPower(lvar,2) * load_t->getBeta();      // quadratic
//                    lCostExprs[t0] += lvar * load_t->getBeta();
//                    lCostExprs[t0] -= 0.5 * load_t->getAlpha() * IloPower(lvar,2);     // if Pl <= beta / alpha
//                     lCostExprs[t0] = (0.5 * IloPower(lvar,2))/load_t->getAlpha();     // if Pl > beta / alpha

                    mapIloLoadIdx[t0][load_t] = iloLoadIdx;
                    mapLoadVar[t0][iloLoadIdx] = load_t;

#ifdef SIMULINK_L
                    if (t == 0) {
                        // Special case for simulator:
                        model.add( lvar == kv.second->getInitialPowerWithdrawn() );
                        totLoad += kv.second->getInitialPowerWithdrawn();
                    }
#endif
                }

                mapIloGenLoad[t0][kv.first] = std::make_pair(iloGenIdx, iloLoadIdx);
            }
#ifdef SIMULINK
            if (t == 0)
                std::cout << "Gen: " << totGen << " Load: " << totLoad << "\n";
#endif
        }

#ifdef DC_CONSTRAINT
        // Constraint: DC Power Flow
        for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon()); t++) {
            int t0 = t - currTime;

            for (auto flow_t : problem->getPowerLines()) {
                int iloFlowIdx = flowVariables[t0].size();
                std::string fName = "line_"+utils::to_string(flow_t->getBusTopID())+"->"
                                    +utils::to_string(flow_t->getBusZID())+"["+utils::to_string(t)+"]";
                IloNumVar fvar(env, flow_t->getMin(), flow_t->getMax(), ILOFLOAT, fName.c_str());
                flowVariables[t0].push_back(fvar);
                mapIloFlowIdx[t0][flow_t] = iloFlowIdx;
                mapFlowVar[t0][iloFlowIdx] = flow_t;

                IloExpr fExpr(env);
                auto shiftFactors = flow_t->getShiftFactors();
                for (int i = 0; i < shiftFactors.size(); i++) {
                    // bus[0] = slack bus
                    int genIdx = mapIloGenLoad[t0][i + 1].first;
                    int loadIdx = mapIloGenLoad[t0][i + 1].second;

                    if (genIdx != -1 && loadIdx != -1) {
                        fExpr += shiftFactors[i] * (genVariables[t0][genIdx] - loadVariables[t0][loadIdx]);
                    } else if (genIdx != -1 && loadIdx == -1) {
                        fExpr += shiftFactors[i] * (genVariables[t0][genIdx]);
                    } else if (genIdx == -1 && loadIdx != -1) {
                        fExpr -= shiftFactors[i] * (loadVariables[t0][loadIdx]);
                    }
                }

                // env.out() << "flow_t: " << fExpr << " MAX:" << flow_t->getMax() << endl;
                model.add(fvar == fExpr);
                model.add(IloAbs(fvar) <= flow_t->getMax());
            }
        }
#endif

#ifdef FLOW_CONSTRAINT
        // Constraints: Conservation of Flow
        for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon()); t++) {
            int t0 = t - currTime;

            IloExpr gExpr(env);
            IloExpr lExpr(env);
            for (auto g : genVariables[t0])
                gExpr += g;
            for (auto l : loadVariables[t0])
                lExpr += l;
            model.add((gExpr - lExpr) == 0);
        }
#endif

#ifdef RAMP_CONSTRAINT
        // Constraints Ramp constraints
        int nVars = genVariables[0].size();
        for (int i = 0; i < nVars; i++) {
            //IloExpr gExpr(env);
            for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon())-1; t++) {
                int t0 = t - currTime;
                model.add(IloAbs(genVariables[t0][i] - genVariables[t0+1][i])
                          <= mapGenVar[t0][i]->getRampDelta());
            }

            if (currTime > 0) {
                IloNum power = mapGenBus[i]->getGeneratorVariable(currTime-1)->getValue();
                IloNum ramp  = mapGenBus[i]->getGeneratorVariable(currTime-1)->getRampDelta();
                model.add(IloAbs(power - genVariables[0][i])  <= ramp);
            }

#ifdef SIMULINK_L
//            IloNum ramp  = 5; //mapGenBus[i]->getLoadVariable(currTime-1)->getRampDelta();
//
//            for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon())-1; t++) {
//                int t0 = t - currTime;
//                model.add(IloAbs(loadVariables[t0][i] - loadVariables[t0+1][i]) <= ramp);
//            }
#endif
        }
#endif
        // Objective function
        IloExpr objExpr(env);
        for (int t = currTime; t < min(currTime + optHorizon, problem->getHorizon()); t++) {
            int t0 = t - currTime;
            objExpr += problem->getProbabilities()[t] * (lCostExprs[t0] - gCostExprs[t0]);
            //objExpr += problem->getProbabilities()[t] * ( - gCostExprs[t0]);
        }

        IloObjective obj(env, objExpr, IloObjective::Maximize);
        model.add(obj);

        // Solve The model
        IloCplex cplex(model);
        cplex.setOut(env.getNullStream());
        cplex.setWarning(env.getNullStream());
        cplex.setError(env.getNullStream());

        cplex.solve();

        // Print Solutions
        if (print) {
            Solver::printSolution(cplex, env);
        }
        Solver::saveSolution(cplex, env);
    }
    catch (IloException& ex) {
        cerr << "Error: " << ex << endl;
    }
    catch (...) {
        cerr << "Error" << endl;
    }
    env.end();
}