//
// Created by Ferdinando Fioretto on 1/19/16.
//

#ifndef TESTCPLEX_INPUTPARAMS_H
#define TESTCPLEX_INPUTPARAMS_H

#include <vector>
#include <sstream>
#include <iostream>

namespace utils {
    template<typename T>
    int findIdx(const std::vector <T> A, T query) {
        for (int i = 0; i < A.size(); ++i)
            if (A[i] == query)
                return i;
        return -1;
    }

    inline int stoi(std::string s) {
        int i;
        std::stringstream ss(s);
        ss >> i;
        return i;
    }

    inline double stod(std::string s) {
        double d;
        std::stringstream ss(s);
        ss >> d;
        return d;
    }
}

class InputParams {
public:

    InputParams(int argc, char** argv) {
        std::vector<std::string> inputs;
        for (int i=0; i < argc; i++) {
            inputs.push_back(argv[i]);
        }

        // Input File in .dat format
        int idx = utils::findIdx(inputs, std::string("--bus-data"));
        if (idx != -1) {
            busDataFileName = inputs[idx + 1];
        } else {
            std::cout << usage();
            exit(-1);
        }

        idx = utils::findIdx(inputs, std::string("--agc-data"));
        if (idx != -1) {
            acgDataFileName = inputs[idx + 1];
        } else {
            std::cout << usage();
            exit(-1);
        }

        idx = utils::findIdx(inputs, std::string("--opt-horizon"));
        optHorizon = (idx != -1) ? utils::stoi(inputs[idx+1]) : 1;

        idx = utils::findIdx(inputs, std::string("--discount"));
        discountFactor = (idx != -1) ? utils::stod(inputs[idx+1]) : 1.0;

        idx = utils::findIdx(inputs, std::string("--congestion-penalty"));
        wFlowPenalty = (idx != -1) ? utils::stod(inputs[idx+1]) : 100.0;
        flowCongestionLimit = (idx != -1) ? utils::stod(inputs[idx+2]) : 0.8;

        idx = utils::findIdx(inputs, std::string("--nsteps"));
        nMaxSteps = (idx != -1) ? utils::stoi(inputs[idx+1]) : 10;

        idx = utils::findIdx(inputs, std::string("--maxerr"));
        maxFlowPenaltyErr = (idx != -1) ? utils::stod(inputs[idx+1]) : 0.1;
    }

    std::string usage() const {
        std::string ret = "ProgramName --bus-data file.dat --agc-data data.dat\n";
        ret += "[--opt-horizon] : The optimization horizon\n";
        ret += "[--discount]    : The discount factor ?\n";
        ret += "[--congestion-penalty]\n";
        ret += "[--nsteps]\n";
        ret += "[--maxerr]\n";
        return ret;
    }

    const std::string &getBusDataFileName() const {
        return busDataFileName;
    }

    const std::string &getAcgDataFileName() const {
        return acgDataFileName;
    }

    int getOptHorizon() const {
        return optHorizon;
    }

    double getDiscountFactor() const {
        return discountFactor;
    }

    double getMaxFlowPenaltyErr() const {
        return maxFlowPenaltyErr;
    }

    int getNMaxSteps() const {
        return nMaxSteps;
    }

    double getWFlowPenalty() const {
        return wFlowPenalty;
    }

    double getFlowCongestionLimit() const {
        return flowCongestionLimit;
    }

    std::string to_string() const {
        return "";
//        return "Problem : " + busDataFileName + " " + acgDataFileName +
//               " optH: " + utils::to_string(optHorizon) +
//               " discount " + utils::to_string(discountFactor) +
//               " iter-params: [" + utils::to_string(maxFlowPenaltyErr) + ", "
//               + string_utils::to_string(nMaxSteps) + "]" +
//               " congestion-params: [" + string_utils::to_string(wFlowPenalty) + ", "
//               + string_utils::to_string(flowCongestionLimit) + "]";
    }

private:

    std::string busDataFileName;
    std::string acgDataFileName;

    // The optimization horizon
    int optHorizon;
    double discountFactor; // [0,1]

    // Parameters for the iteratve process
    double maxFlowPenaltyErr; // [0,1]
    int nMaxSteps;

    double wFlowPenalty; // [initial multiplier] (alpha)
    double flowCongestionLimit; // [0,1] (m)
};


#endif //TESTCPLEX_INPUTPARAMS_H
