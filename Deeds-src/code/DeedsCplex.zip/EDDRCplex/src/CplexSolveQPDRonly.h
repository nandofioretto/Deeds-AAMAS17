//
// Created by Ferdinando Fioretto on 1/28/16.
//

#ifndef EDDRCPLEX_CPLEXSOLVEQPDRONLY_H
#define EDDRCPLEX_CPLEXSOLVEQPDRONLY_H


#include "Problem.h"
#include "Solver.h"

class CplexSolveQPDRonly : public Solver {
public:
    CplexSolveQPDRonly(Problem& p) :
    Solver(p)
            { }

    void iSolve(bool print=false);
};


#endif //EDDRCPLEX_CPLEXSOLVEQPDRONLY_H
