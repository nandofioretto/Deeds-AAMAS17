//
// Created by Ferdinando Fioretto on 1/19/16.
//

#ifndef TESTCPLEX_PROBLEM_H
#define TESTCPLEX_PROBLEM_H

#include <string>
#include <map>
#include <vector>
#include <iostream>

#include "BusAgent.h"
#include "FlowVariable.h"
#include "GeneratorVariable.h"
#include "LoadVariable.h"

#define NORM_PROB
#define ADD_NOISE

class Problem {
public:
    typedef Problem* ptr;

    Problem(std::string busFilname, std::string agcFilename);

    const std::vector<double> &getProbabilities() const {
        return probabilities;
    }

    int getHorizon() const {
        return horizon;
    }

    const std::map<int, BusAgent::ptr> &getPowerNetwork() const {
        return powerNetwork;
    }

    const std::vector<FlowVariable::ptr> &getPowerLines() const {
        return powerLines;
    }

    int getNbBuses() {
        return powerNetwork.size();
    }

    std::string to_string() const {
        std::string ret;
        for (auto& kv : powerNetwork) {
            ret += kv.second->to_string() + "\n";
        }
        return ret;
    }

    void reset() {
        for (int t = 0; t < horizon; t++) {
            for (auto &kv : powerNetwork) {
                kv.second->getGeneratorVariable(t)->resetValue();
                kv.second->getLoadVariable(t)->resetValue();
            }
        }
        for (auto& flow : powerLines) {
            flow->resetValues();
        }
    }

    cost_t computeCost() {
        cost_t cost = 0;
        for (int t = 0; t < horizon; t++) {
            cost_t genCost_t  = 0;
            cost_t loadCost_t = 0;

            for (auto &kv : powerNetwork) {
                auto& gen_t  = kv.second->getGeneratorVariable(t);
                auto& load_t = kv.second->getLoadVariable(t);

                genCost_t  += gen_t->getCost();
                loadCost_t += load_t->getCost();
            }
            cost += probabilities[t] * (loadCost_t - genCost_t);
        }
        return cost;
    }

    void printHorizonCosts() {
        std::cout << "Time\tGens\t Loads\t Utility\tMW\n";
        for (int t = 0; t < horizon; t++) {
            cost_t genCost_t  = 0;
            cost_t loadCost_t = 0;
            power_t powerGen  = 0;
            for (auto &kv : powerNetwork) {
                auto& gen_t  = kv.second->getGeneratorVariable(t);
                auto& load_t = kv.second->getLoadVariable(t);

                genCost_t  += gen_t->getCost();
                loadCost_t += load_t->getCost();
                powerGen += gen_t->getValue();
            }
            std::cout << t << "\t" << genCost_t << "\t" << loadCost_t << "\t" << (loadCost_t - genCost_t)
            << "\t" << powerGen << "\n";
        }
    }

    void printSpecial(int secInterval) {
        std::cout << "\n============================ MATLAB SCRIPT ==============================\n";

        int gIDs[] = {1,2,5,8,11,13};
        int lIDs[] = {4,7,10,12,15,30};

        int Hsec = secInterval * (horizon - 1);
        int Isec = secInterval*2;
        std::cout << "x = linspace(0, " << Hsec << " , " << 2*Hsec + 1 << ")\n";
        std::cout << "sigma = 0.05" << std::endl;

        std::map<int, double> yeBus;
        yeBus[1] =  179.987;
        yeBus[2] =  53.8556;
        yeBus[5] =  25.6613;
        yeBus[8] =  24.169;
        yeBus[11] =  19.1512;
        yeBus[13] =  22.4683;
        yeBus[4] = 44;
        yeBus[7] = 47.025;
        yeBus[10] = 40;
        yeBus[12] = 40;
        yeBus[15] = 33;
        yeBus[30] = 25;
        // Generators
        for (int id : gIDs) {
            auto bus = powerNetwork[id];

            auto &gen_t0 = bus->getGeneratorVariable(0);
            std::cout << "g" << id << "_t{1} = "
            << "linspace(" << yeBus[id] << ", " << gen_t0->getValue() << ", " << Isec+1 << ")\n";

            for (int t = 0; t < horizon-2; t++) {
                auto &gen_t0 = bus->getGeneratorVariable(t);
                auto &gen_t1 = bus->getGeneratorVariable(t+1);

                std::cout << "g" << id << "_t{" << t+2 << "} = "
                << "linspace(" << gen_t0->getValue()  << ", " << gen_t1->getValue() << ", " << Isec << ")\n";
            }
        }

        // sigma = (1-p) mu/10
        //  Loads
        for (int id : lIDs) {
            auto bus = powerNetwork[id];

            auto &l_t0 = bus->getLoadVariable(0);
            std::cout << "l" << id << "_t{1} = "
            << "linspace(" << yeBus[id] << ", " << l_t0->getValue() << ", " << Isec+1 << ")\n";

            for (int t = 0; t < horizon; t++) {
                double mu = bus->getLoadVariable(t)->getValue();
                double sigma = (1 - probabilities[t]) * (mu / 5);
                std::cout << "value_l_" << id << "_" << t << " = ";
                if (t == 0) {
                    std::cout << mu << "\n";
                } else {
#ifdef NORM_PROB
                    std::cout << "normrnd(" << mu << "," << sigma << ")\n";
#else
                    std::cout << mu << "\n";
#endif
                }
            }
            for (int t = 0; t < horizon-2; t++) {
                auto &l_t0 = bus->getLoadVariable(t);
                auto &l_t1 = bus->getLoadVariable(t+1);

                std::cout << "l" << id << "_t{" << t+2 << "} = "
#ifdef ADD_NOISE
                << "makeNoise("
#endif
                    << "linspace(value_l_"<<id<<"_"<<t<< ", " << "value_l_"<<id<<"_"<<t+1<<", "<<Isec<<")"
#ifdef ADD_NOISE
                << ", sigma)"
#endif
                << std::endl;
            }
        }

        // Merge vectors
        int i = 1;
        for (int id : gIDs) {
            std::cout << "gen_" << i << " = " << "[x; ";
            for (int t = 0; t < horizon - 1; t++) {
                std::cout << "g" << id << "_t{" << t+1 << "}";
                if (t < horizon - 2 ) std::cout << ", ";
            }
            std::cout << "]\n";
            std::cout << "save \'g" << i << ".mat\' gen_"<< i << "\n";
            i++;
        }

        i = 1;
        for (int id : lIDs) {
            std::cout << "load_" << i << " = " << "[x; ";
            for (int t = 0; t < horizon - 1; t++) {
                std::cout << "l" << id << "_t{" << t+1 << "}";
                if (t < horizon - 2 ) std::cout << ", ";
            }
            std::cout << "]\n";
            std::cout << "save \'l" << i << ".mat\' load_"<< i << "\n";
            i++;
        }

    }

    bool checkConstraintViolations() {
        for (int t = 0; t < horizon; t++) {
            for (auto& flow : powerLines) {
                if (flow->isViolated(t)) {
                    std::cout << "violation at " << flow->getBusTopID() << " - " << flow->getBusZID() << " time :" << t << std::endl;
                    return false;
                }
            }
        }
        return true;
    }

    void computeShiftFactor();

    void readHorizon(std::ifstream& inData);

    void readGenerator(const std::string& busData, const std::string& busParams, BusAgent::ptr busAgent);

    void readLoad(const std::string& busData, const std::string& busParams, BusAgent::ptr busAgent);

    std::string getBusLine(std::ifstream& infileData, int busID, char busType);

    void readBusData(std::string busFilename);
    void readAGCData(std::string acgFilename);

private:
    int horizon;
    std::vector<double> probabilities;

    std::map<int, BusAgent::ptr> powerNetwork;
    std::vector<FlowVariable::ptr> powerLines; // directed power lines

};


#endif //TESTCPLEX_PROBLEM_H
