//
// Created by Ferdinando Fioretto on 1/20/16.
//

#ifndef TESTCPLEX_CPLEXSOLVERQPRELAX_H
#define TESTCPLEX_CPLEXSOLVERQPRELAX_H

#include "Solver.h"

class CplexSolverQPrelax : public Solver {
public:
    CplexSolverQPrelax(Problem& p) :
    Solver(p)
            { }

    void iSolve(bool print=true);

    void solve(int optHorizon, double w, double m, int nIter, double maxErr, bool print=true);

private:
    double m_penlty;
    double w_penlty;
};


#endif //TESTCPLEX_CPLEXSOLVERQPRELAX_H
