//
// Created by Ferdinando Fioretto on 1/21/16.
//

#ifndef TESTCPLEX_UTILS_H
#define TESTCPLEX_UTILS_H

#endif //TESTCPLEX_UTILS_H

#include <algorithm>
#include <string>
#include <sstream>
#include <vector>

namespace utils{


    template < typename T > std::string to_string( const T& n )
    {
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }

    inline std::string to_string(const std::vector<std::string> &pValues) {
        std::string result = "";
        for (auto val : pValues)
            result += val + ", ";
        return result;
    }

    template<typename T, typename U>
    std::string to_string(const std::pair<T,U>& p) {
        return "(" + to_string(p.first) + ", " + to_string(p.second) + ")";
    }

    // It returns the description of the array content given as a parameter.
    template<typename T>
    std::string to_string(const std::vector<T> &array) {
        std::string res = "{";
        for (int i = 0; i < array.size(); ++i) {
            res += to_string(((int)(array[i] * 100 + .5) / 100.0));
            if (i < array.size() - 1) res += ", ";
        }
        res += "}";
        return res;
    }

    template<typename T>
    std::string to_string(const std::vector<std::vector<T> > pMatrix) {
        std::string res;
        for (int i = 0; i < pMatrix.size(); ++i) {
            for (int j = 0; j < pMatrix[i].size(); ++j) {
                res += to_string(pMatrix[i][j]);
                if (j < pMatrix[i].size() - 1) res += ", ";
            }
            res += "\n";
        }
        return res;
    }

    // It returns the description of the array content given as a parameter.
    template<typename T, typename U>
    std::string to_string(const std::vector<std::pair<T, U> > pArray) {
        std::string res = "{";
        for (int i = 0; i < pArray.size(); ++i) {
            res += "(" + to_string(pArray[i].first) + ", "
                   + to_string(pArray[i].second) + ")";
            if (i < pArray.size() - 1) res += ", ";
        }
        res += "}";
        return res;
    }
};