#include <InputParams.h>
#include <Problem.h>
#include <CplexSolverQPrelax.h>
#include <CplexSolveQPDRonly.h>
#include "CplexSolverQP.h"

int main(int argc, char** argv)
{
    auto inputs  = InputParams(argc, argv);
    auto problem = Problem(inputs.getBusDataFileName(), inputs.getAcgDataFileName());


    // Todo: Read multipliers for each flow:
    // F1: c11 * p1 + c12 * p2 + ... * c1n * pn <= max_1
    // F2: c21 * p1 + c22 * p2 + ... * c2n * pn <= max_2
    // ...
    int H = inputs.getOptHorizon();// problem.getHorizon();


    CplexSolverQP solverQP(problem);
    solverQP.solve(H, false);
    std::cout << "DR ED Problem Cost: " << problem.computeCost() << "\n";
    std::cout << "DR ED Problem check: " << problem.checkConstraintViolations() << "\n";
    problem.printHorizonCosts();
    // problem.printSpecial(20);

//    return 0;
//    problem.reset();
//    CplexSolveQPDRonly solverDR(problem);
//    solverDR.solve(H);
//    std::cout << "DR Problem Cost: " << problem.computeCost() << "\n";
//    std::cout << "DR Problem check: " << problem.checkConstraintViolations() << "\n";
//    problem.printHorizonCosts();

    problem.reset();
    CplexSolverQPrelax solverQPrelax(problem);
    solverQPrelax.solve(H, 100, 0.95, 10, 0.0001, false);
    std::cout << "Problem Cost: " << problem.computeCost() << "\n";
    std::cout << "Problem check: " << problem.checkConstraintViolations() << "\n";
    problem.printHorizonCosts();
    return 0;
}

/*
Cost:653.554
Pure metal:
0) 0
1) 0
2) 0
Raw material:
0) 0
1) 0
Scrap:
0) 17.059
1) 30.2311
Ingots : 
0) 32.4769
Elements:
0) 3.55
1) 24.85
2) 42.6
*/
