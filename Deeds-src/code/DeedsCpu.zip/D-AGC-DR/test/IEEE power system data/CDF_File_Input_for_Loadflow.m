%% Sample program to read data from IEEE Common Data Format (Tried on 30 Bus Data)
%% Bus Data and Line Data are read into matrices which can be used for load flow
%% Please Refer: http://www.ee.washington.edu/research/pstca/pf30/pg_tca30bus.htm
%% Coded by: Krishnanand K.R., ECE, National University of Singapore
%% Supervisor: Prof. Sanjib K. Panda, ECE, National University of Singapore
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; clc;
fid = fopen('ieee162cdf.txt');

%% BUS Data
Line_String_Complete=fgetl(fid); Line_String_Complete=fgetl(fid);
Bus_Data=[]; No_of_Buses=0;
while ischar(Line_String_Complete)
    Line_String_Complete=fgetl(fid);
%     disp(['#' Line_String_Complete '#'] );
    if(strcmp(Line_String_Complete(1:4),'-999')==1); break; end
    index=15; Line_String_Numeric=Line_String_Complete(index:end);    
    Line_Numeric=str2num(Line_String_Numeric);
    No_of_Buses=No_of_Buses+1;
    Bus_Data=[Bus_Data; [No_of_Buses Line_Numeric] ];
end

%% Line Data
Line_String_Complete=fgetl(fid);
Line_Data=[]; No_of_Lines=0;
while ischar(Line_String_Complete)
    Line_String_Complete=fgetl(fid);
%     disp(['#' Line_String_Complete '#'] );
    if(strcmp(Line_String_Complete(1:4),'-999')==1); break; end
    index=1; Line_String_Numeric=Line_String_Complete(index:end);    
    Line_Numeric=str2num(Line_String_Numeric);
    No_of_Lines=No_of_Lines+1;
    Line_Data=[Line_Data; [No_of_Lines Line_Numeric]];
end

fclose(fid);

%%
Bus_Data
Line_Data
No_of_Buses
No_of_Lines

