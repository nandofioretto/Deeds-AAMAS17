//
// Created by Ferdinando Fioretto on 10/31/15.
//

#ifndef D_AGC_DR_PROBLEM_H
#define D_AGC_DR_PROBLEM_H

#include <string>
#include <map>

#include "BusAgent.h"
#include "string_utils.hpp"

class Problem {
public:
    typedef std::shared_ptr<Problem> ptr;

    Problem(std::string busFilname, std::string agcFilename);

    const std::vector<double> &getProbabilities() const {
        return probabilities;
    }

    int getHorizon() const {
        return horizon;
    }

    const std::map<int, BusAgent::ptr> &getPowerNetwork() const {
        return powerNetwork;
    }

    const std::vector<FlowVariable::ptr> &getPowerLines() const {
        return powerLines;
    }

    int getNbBuses() {
        return powerNetwork.size();
    }

    bool checkConstraintViolations() {
        for (int t = 0; t < horizon; t++) {
            for (auto& flow : powerLines) {
                if (flow->isViolated(t)) {
                    std::cout << "violation at " << flow->getBusTopID() << " - " << flow->getBusZID() << " time :" << t << std::endl;
                    return false;
                }
            }
        }
        return true;
    }


    void computeShiftFactor();

    void readHorizon(std::ifstream& inData);

    void readGenerator(const std::string& busData, const std::string& busParams, BusAgent::ptr busAgent);

    void readLoad(const std::string& busData, const std::string& busParams, BusAgent::ptr busAgent);

    std::string getBusLine(std::ifstream& infileData, int busID, char busType);

    void readBusData(std::string busFilename);
    void readAGCData(std::string acgFilename);

    cost_t computeCost() {
        cost_t cost = 0;
        for (int t = 0; t < horizon; t++) {
            cost_t genCost_t  = 0;
            cost_t loadCost_t = 0;

            for (auto &kv : powerNetwork) {
                auto& gen_t  = kv.second->getGeneratorVariable(t);
                auto& load_t = kv.second->getLoadVariable(t);

                genCost_t  += gen_t->getCost();
                loadCost_t += load_t->getCost();
            }
            cost += probabilities[t] * (loadCost_t - genCost_t);
        }
        return cost;
    }

    std::string printHorizonCosts() {
        std::string ret = "Time\t Gens\t Loads\t Utility\t MW\n";
        for (int t = 0; t < horizon; t++) {
            cost_t genCost_t  = 0;
            cost_t loadCost_t = 0;
            power_t powerGen  = 0;

            for (auto &kv : powerNetwork) {
                auto& gen_t  = kv.second->getGeneratorVariable(t);
                auto& load_t = kv.second->getLoadVariable(t);

                genCost_t  += gen_t->getCost();
                loadCost_t += load_t->getCost();
                powerGen   += gen_t->getValue();
            }
            ret += std::to_string(t)
                   + "\t" + std::to_string(genCost_t)
                   + "\t" + std::to_string(loadCost_t)
                   + "\t" + std::to_string(loadCost_t - genCost_t)
                   + "\t" + std::to_string(powerGen) + "\n";
        }

        ret += "Total Utility: " + std::to_string(computeCost()) + "\n";
        return ret;
    }

    std::string to_string() const {
        std::string ret = "H= " + std::to_string(horizon) + " wFlowPenality=" +
                          misc_utils::string_utils::to_string(probabilities) + "\n";
        for (auto& kv : powerNetwork) {
            ret += kv.second->to_string() + "\n";
        }
        return ret;
    }


private:
    int horizon;
    std::vector<double> probabilities;

    std::map<int, BusAgent::ptr> powerNetwork;
    std::vector<FlowVariable::ptr> powerLines; // directed power lines
};


#endif //D_AGC_DR_PROBLEM_H
