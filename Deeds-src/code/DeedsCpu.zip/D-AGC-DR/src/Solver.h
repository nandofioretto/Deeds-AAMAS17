//
// Created by Ferdinando Fioretto on 11/3/15.
//

#ifndef D_AGC_DR_SOLVER_H
#define D_AGC_DR_SOLVER_H

#include "Problem.h"

class Solver {
public:
    Solver(int horizon) : horizon(horizon), currTime(0)
    { }

    virtual void solve() = 0;

    int getHorizon() const {
        return horizon;
    }

    int getCurrTime() const {
        return currTime;
    }

    void incrCurrTime() {
        Solver::currTime++;
    }

private:
    int horizon;
    int currTime;
};

#endif //D_AGC_DR_SOLVER_H
