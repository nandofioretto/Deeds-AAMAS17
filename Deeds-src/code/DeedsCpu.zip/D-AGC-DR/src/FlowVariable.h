//
// Created by Ferdinando Fioretto on 10/31/15.
//

#ifndef D_AGC_DR_FLOWVARIABLE_H
#define D_AGC_DR_FLOWVARIABLE_H


#include <memory>
#include <complex>

class FlowVariable {

public:
    typedef std::shared_ptr<FlowVariable> ptr;

    FlowVariable(int busTopID, int busZID, double min, double max, double resistance, double reactance, bool outgoing)
            : busTopID(busTopID), busZID(busZID), min(min), max(max), outgoing(outgoing) {
        impedance = std::complex<double>(resistance, reactance);
    }

    double getMin() const {
        return min;
    }

    double getMax() const {
        return max;
    }

    double getResistance() const {
        return impedance.real();
    }

    double getReactance() const {
        return impedance.imag();
    }

    const std::complex<double> &getImpedance() const {
        return impedance;
    }

    int getBusTopID() const {
        return busTopID;
    }

    int getBusZID() const {
        return busZID;
    }

    double getValue() const {
        return value;
    }

    void setValue(double value) {
        FlowVariable::value = value;
    }

    void setOutgoing(bool value=true) {
        outgoing = value;
    }

    bool isIncoming() const {
        return !outgoing;
    }

    bool isOutgoing() const {
        return outgoing;
    }

    bool isViolated(int t) {
        return (std::abs(value) > max);
    }

    const std::vector<double> &getShiftFactors() const {
        return shiftFactors;
    }

    void setShiftFactors(const std::vector<double> &shiftFactors) {
        FlowVariable::shiftFactors = shiftFactors;
    }

    std::string to_string() const {
        return "Flow: " + std::to_string(busTopID) + " -> " + std::to_string(busZID)
               + " [" + std::to_string(min) + ", " + std::to_string(max) + "] "
               + "(" + std::to_string(impedance.real()) + " + j" + std::to_string(impedance.imag()) + ")";
    }

private:
    double min, max;
    // Z = R + jX, Resistance (R) + Reactance (X) all measured in Ohms (j = sqrt(-1))
    std::complex<double> impedance;
    int busTopID, busZID;
    bool outgoing; // true = outgoing flow; false = incoming flow;
    double value;

    // The shift Factor row of the C-matrix associated to this line flow.
    // Contains the multipliers for the active generators, except the slack bus.
    std::vector<double> shiftFactors;
};


#endif //D_AGC_DR_FLOWVARIABLE_H
