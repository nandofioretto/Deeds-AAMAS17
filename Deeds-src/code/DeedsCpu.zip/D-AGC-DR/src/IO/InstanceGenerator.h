//
// Created by Ferdinando Fioretto on 1/28/16.
//

#ifndef D_AGC_DR_INSTANCEGENERATOR_H
#define D_AGC_DR_INSTANCEGENERATOR_H


#include <iosfwd>
#include <Problem.h>
#include <fstream>
#include <random>
#include "string_utils.hpp"

using namespace misc_utils;

class InstanceGenerator {

public:
    InstanceGenerator(Problem::ptr P)
            : problem(P), instanceNumber(0)
    { }


    void to_string(std::string fileName) {
        auto pf = string_utils::split_path_file(fileName);
        std::string file = pf[0] + "/" + pf[1] + "_" + std::to_string(instanceNumber) + ".dat";
        std::ofstream ofs;
        ofs.open(file, std::ofstream::out);
        std::cout << file  << std::endl;

        unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
//        std::uniform_real_distribution<double> uniAlpha(0.1, 0.5);
//        std::uniform_real_distribution<double> uniBeta(0.01, 0.05);
//        std::uniform_real_distribution<double> uniAlphaDisp(0.25, 1);
//        std::uniform_real_distribution<double> uniBetaDisp(0.05, 0.5);

        std::default_random_engine generator(seed);

        ofs << "PROBLEM DATA FOLLOWS" << std::endl;
        ofs << problem->getHorizon() << " ";
        double PrMax = 1.0; double PrMin = 1.0;
        for (int i=0; i<problem->getHorizon(); i++) {
            std::uniform_real_distribution<double> uniPr(PrMin, PrMax);
            ofs << uniPr(generator) << " ";
            PrMin -= 0.05;
        }
        ofs << std::endl;
        ofs << "-999" << std::endl;

        ofs << "BUS DATA FOLLOWS" << std::endl;

        for (auto& kv : problem->getPowerNetwork()) {
            auto bus = kv.second;
            ofs << bus->getBusID() + 1 << " ";
            if (bus->isGenerator()) {
                auto gen = bus->getGeneratorVariable(0);
                ofs << "G " << gen->getAlpha() << " " << gen->getBeta() << " "
                    << gen->getEpsilon() << " " << gen->getPhi() << " "
                    << bus->getInitialPowerInjected() << std::endl;
            }
            if (bus->isLoad()) {
                auto load = bus->getLoadVariable(0);
                ofs << "L " << load->getAlpha() << " " << load->getBeta() << " "
                    << bus->getInitialPowerWithdrawn() << " ";
//                if(bus->isDispatchable()) {
//                    ofs << "L " << uniAlpha(generator) << " " << uniBeta(generator) << " ";
//                } else {
//                    ofs << "L " << uniAlphaDisp(generator) << " " << uniBetaDisp(generator) << " ";
//                }

                double mean = bus->getInitialPowerWithdrawn();
//              std::normal_distribution<double> normal(mean, sqrt(mean)/10);
                std::normal_distribution<double> normal(mean, mean/10);

                for (int i=1; i<problem->getHorizon(); i++) {
                    double power;
                    do {
                        // SPECIAL CASE FOR THE SIMULATOR:
                        power = (!bus->isDispatchable()) ? mean :
                                                      normal(generator);
                    } while (power > load->getMax() || power < load->getMin());

                    ofs << power << " ";
                }
                ofs << std::endl;
            }
        }

        ofs << "-999" << std::endl;
        ofs.close();

        instanceNumber++;
    }

private:
    Problem::ptr problem;
    int instanceNumber;

};


#endif //D_AGC_DR_INSTANCEGENERATOR_H
