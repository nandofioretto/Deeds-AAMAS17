//
// Created by Ferdinando Fioretto on 10/30/15.
//

#include <sstream>
#include <fstream>
#include <iostream>

#include "IO/IEEEGraph.h"

using namespace IEEEPowerSystem;

void IEEEGraph::import(std::string filename) {

    std::ifstream infile(filename, std::ios::in | std::ios::binary);

    if (infile) {

        std::string line;
        // skip first two lines
        std::getline(infile, line);
        std::getline(infile, line);
        std::stringstream ss(line);
        std::string s;
        ss >> s; ss >> s; ss >> s >> nbNodes;
        std::cout<< "NBnodes: " << nbNodes << std::endl;
        IEEEGraph::inititalize(nbNodes);

        int busNumber, loadFlowAreaNumber, lossZoneNumber, busType, remoteControlledBusNumber;
        std::string busName, busVoltageType;
        double finalVoltagePU, finalAngleDegrees, loadMW, loadMVAR, generationMW, generationMVAR,
                baseKV, desiredVoltsPU, maximumMVAR, minimumMVAR, shuntConductancePU, shuntSusceptancePU;

        while( std::getline(infile, line) ) {
            if (line.find("-999") == 0) break;

            busNumber = std::stoi(line.substr(0,4));
            busName = line.substr(5,8);
            std::stringstream ss(line.substr(14));
            ss >> busVoltageType >> loadFlowAreaNumber >> lossZoneNumber >> busType
                >> finalVoltagePU >> finalAngleDegrees  >> loadMW >> loadMVAR >> generationMW
                >> generationMVAR >> baseKV >> desiredVoltsPU >> maximumMVAR >> minimumMVAR >> shuntConductancePU
                >> shuntSusceptancePU >> remoteControlledBusNumber;

            IEEEBus::ptr bus = std::make_shared<IEEEBus>(busNumber, busName, busVoltageType, loadFlowAreaNumber, lossZoneNumber, busType,
            finalVoltagePU, finalAngleDegrees, loadMW, loadMVAR, generationMW, generationMVAR, baseKV,
            desiredVoltsPU, maximumMVAR, minimumMVAR, shuntConductancePU, shuntSusceptancePU, remoteControlledBusNumber);

            IEEEGraph::newNode(busNumber, bus);
        }

        // skip next lines
        std::getline(infile, line);

        int tapBusId, zBusId, loadFlowArea, lossZone, circuit, branchType, lineMVAno1, lineMVAno2, lineMVAno3,
                controlBusNb, branchSide;
        double branchResistancePU, branchReactancePU, lineChargingPU, transformerFinalTurnsRatio, transformerFinalAngle,
        minPhaseShift, maxPhaseShift, stepSize, minVoltageMW, maxVoltageMW;

        while( std::getline(infile, line) ) {
            if (line.find("-999") == 0) break;
            std::stringstream ss(line);

            ss >> tapBusId >> zBusId >> loadFlowArea >> lossZone >> circuit >> branchType >> branchResistancePU
                >> branchReactancePU >> lineChargingPU >> lineMVAno1 >> lineMVAno2 >> lineMVAno3 >> controlBusNb
                >> branchSide >> transformerFinalTurnsRatio >> transformerFinalAngle >> minPhaseShift >> maxPhaseShift
                >> stepSize >> minVoltageMW >> maxVoltageMW;

            auto branch = std::make_shared<IEEEBranch>(tapBusId, zBusId, loadFlowArea, lossZone, circuit, branchType,
                                                       lineMVAno1, lineMVAno2, lineMVAno3, controlBusNb, branchSide,
                                                       branchResistancePU, branchReactancePU, lineChargingPU,
                                                       transformerFinalTurnsRatio, transformerFinalAngle, minPhaseShift,
                                                       maxPhaseShift, stepSize, minVoltageMW, maxVoltageMW);
            IEEEGraph::newEdge(tapBusId, zBusId, branch);
        }
    }
    else {
        throw(std::runtime_error("File " + filename + " not found"));
    }

}
