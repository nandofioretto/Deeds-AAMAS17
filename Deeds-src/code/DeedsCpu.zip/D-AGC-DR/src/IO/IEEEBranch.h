//
// Created by Ferdinando Fioretto on 10/30/15.
//

#ifndef D_AGC_DR_IEEEBRANCH_H
#define D_AGC_DR_IEEEBRANCH_H

#include <string>

namespace IEEEPowerSystem {
    class IEEEBranch {
    public:
        typedef std::shared_ptr<IEEEBranch> ptr;

        /**
         *
         * Tap bus number:  For transformers or phase shifters, the side of the model the non-unity tap is on.
         * Z bus number:    For transformers and phase shifters, the side of the model the device impedance is on.
         * Load flow area
         * Loss zone
         * Circuit (Use 1 for single lines)
         * Type (I):
         *      0 - Transmission line
         *      1 - Fixed tap
         *      2 - Variable tap for voltage control (TCUL, LTC)
         *      3 - Variable tap (turns ratio) for MVAR control
         *      4 - Variable phase angle for MW control (phase shifter)
         * Branch resistance R, per unit.
         * Branch reactance X, per unit --  No zero impedance lines.
         * Line charging B, per unit. (total line charging, +B)
         * Line MVA rating No 1.
         * Line MVA rating No 2.
         * Line MVA rating No 3.
         * Control bus number.
         * Side:
         *      0 - Controlled bus is one of the terminals
         *      1 - Controlled bus is near the tap side
         *      2 - Controlled bus is near the impedance side (Z bus)
         * Transformer final turns ratio.
         * Transformer (phase shifter) final angle.
         * Minimum tap or phase shift.
         * Maximum tap or phase shift.
         * Step size.
         * Minimum voltage, MVAR or MW limit.
         * Maximum voltage, MVAR or MW limit (F)
         */
        IEEEBranch(int tapBusId, int zBusId, int loadFlowArea, int lossZone, int circuit, int branchType,
                   int lineMVAno1, int lineMVAno2, int lineMVAno3, int controlBusNb, int branchSide,
                   double branchResistancePU, double branchReactancePU, double lineChargingPU,
                   double transformerFinalTurnsRatio, double transformerFinalAngle, double minPhaseShift,
                   double maxPhaseShift, double stepSize, double minVoltageMW, double maxVoltageMW)
                : tapBusId(tapBusId), zBusId(zBusId), loadFlowArea(loadFlowArea), lossZone(lossZone),
                  circuit(circuit), branchType(branchType), lineMVAno1(lineMVAno1), lineMVAno2(lineMVAno2),
                  lineMVAno3(lineMVAno3), controlBusNb(controlBusNb), branchSide(branchSide),
                  branchResistancePU(branchResistancePU), branchReactancePU(branchReactancePU), lineChargingPU(lineChargingPU),
                  transformerFinalTurnsRatio(transformerFinalTurnsRatio), transformerFinalAngle(transformerFinalAngle),
                  minPhaseShift(minPhaseShift), maxPhaseShift(maxPhaseShift), stepSize(stepSize),
                  minVoltageMW(minVoltageMW), maxVoltageMW(maxVoltageMW) { }


        int getTapBusId() const {
            return tapBusId;
        }

        int getZBusId() const {
            return zBusId;
        }

        int getLoadFlowArea() const {
            return loadFlowArea;
        }

        int getLossZone() const {
            return lossZone;
        }

        int getCircuit() const {
            return circuit;
        }

        int getBranchType() const {
            return branchType;
        }

        int getLineMVAno1() const {
            return lineMVAno1;
        }

        int getLineMVAno2() const {
            return lineMVAno2;
        }

        int getLineMVAno3() const {
            return lineMVAno3;
        }

        int getControlBusNb() const {
            return controlBusNb;
        }

        int getBranchSide() const {
            return branchSide;
        }

        double getBranchResistancePU() const {
            return branchResistancePU;
        }

        double getBranchReactancePU() const {
            return branchReactancePU;
        }

        double getLineChargingPU() const {
            return lineChargingPU;
        }

        double getTransformerFinalTurnsRatio() const {
            return transformerFinalTurnsRatio;
        }

        double getTransformerFinalAngle() const {
            return transformerFinalAngle;
        }

        double getMinPhaseShift() const {
            return minPhaseShift;
        }

        double getMaxPhaseShift() const {
            return maxPhaseShift;
        }

        double getStepSize() const {
            return stepSize;
        }

        double getMinVoltageMW() const {
            return minVoltageMW;
        }

        double getMaxVoltageMW() const {
            return maxVoltageMW;
        }

        std::string to_string() const  {
            return "Branch (" + std::to_string(tapBusId) + ", " + std::to_string(zBusId)
                    + ") R= " + std::to_string(branchResistancePU)
                    + "  X= " + std::to_string(branchReactancePU)
                    + " MW= [" + std::to_string(minVoltageMW) + ", " + std::to_string(maxVoltageMW) + "]";
        }

    private:
        int tapBusId, zBusId, loadFlowArea, lossZone, circuit, branchType, lineMVAno1, lineMVAno2, lineMVAno3,
                controlBusNb, branchSide;
        double branchResistancePU, branchReactancePU, lineChargingPU, transformerFinalTurnsRatio, transformerFinalAngle,
                minPhaseShift, maxPhaseShift, stepSize, minVoltageMW, maxVoltageMW;
    };
}


#endif //D_AGC_DR_IEEEBRANCH_H
