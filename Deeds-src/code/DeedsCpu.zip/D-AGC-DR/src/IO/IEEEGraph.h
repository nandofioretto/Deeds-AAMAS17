//
// Created by Ferdinando Fioretto on 10/30/15.
//

#ifndef D_AGC_DR_IEEEGRAPH_H
#define D_AGC_DR_IEEEGRAPH_H


#include <string>
#include <vector>
#include <map>
#include "IO/IEEEBus.h"
#include "IO/IEEEBranch.h"

namespace IEEEPowerSystem {

    class IEEEGraph {
        typedef std::shared_ptr<IEEEGraph> ptr;

    public:
        IEEEGraph(std::string filename) {
            import(filename);
        }

        void inititalize(int nbNodes) {
            this->nbNodes = nbNodes;
            nodes.reserve(nbNodes);
            edges.resize(nbNodes);
            for (int i = 0; i < nbNodes; i++) {
                edges[i].resize(nbNodes, false);
            }
        }

        void import(std::string filename);

        void newEdge(int naId, int nbId, IEEEBranch::ptr branch) {
            edges[nodeIdToIdx[naId]][nodeIdToIdx[nbId]] = true;
            edges[nodeIdToIdx[nbId]][nodeIdToIdx[naId]] = true;
            branches[std::make_pair(naId,nbId)] = branch;
        }

        void newNode(int nodeId, IEEEBus::ptr bus) {
            int nextNode = nodes.size();
            if (nextNode > nbNodes) throw (errno);
            nodes.push_back(nodeId);
            nodeIdToIdx[nodeId] = nextNode;
            buses[nodeId] = bus;
        }

        IEEEBranch::ptr getEdge(int naId, int nbId) {
            auto edge = std::make_pair(nodeIdToIdx[naId], nodeIdToIdx[nbId]);
            if (branches.find(edge) == branches.end())
                throw(errno);
            else
                return branches[edge];
        }

        IEEEBus::ptr getBus(int id) {
            if (buses.find(id) == buses.end())
                throw(errno);
            else
                return buses[id];
        }

        int getNbNodes() const {
            return nodes.size();
        }

        int getNbEdges() const {
            return edges.size();
        }

        std::string to_string() const {
            std::string ret;
            for(auto& kv : buses) {
                ret += kv.second->to_string() + "\n";
            }
            for(auto& kv : branches) {
                ret += kv.second->to_string() + "\n";
            }
            return ret;
        }



    private:
        std::map<int, IEEEBus::ptr> buses;
        std::map<std::pair<int,int>, IEEEBranch::ptr> branches;

        std::vector<int> nodes;  // nodeId
        std::vector<std::vector<bool>> edges; // (nodeId, nodeId)

        int nbNodes;
        std::map<int, int> nodeIdToIdx;
    };
}

#endif //D_AGC_DR_IEEEGRAPH_H
