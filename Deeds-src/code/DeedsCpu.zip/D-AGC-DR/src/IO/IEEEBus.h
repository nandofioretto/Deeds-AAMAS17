//
// Created by Ferdinando Fioretto on 10/30/15.
//

#ifndef D_AGC_DR_IEEEBUS_H
#define D_AGC_DR_IEEEBUS_H

#include <string>
#include <memory>

namespace IEEEPowerSystem {
    class IEEEBus {

    public:
        typedef std::shared_ptr<IEEEBus> ptr;

        /** 
         * Bus number.
         * Name.
         * Load flow area number.
         * Loss zone number.
         * Type:
         *       0 - Unregulated (load, PQ)
         *       1 - Hold MVAR generation within voltage limits, (PQ)
         *       2 - Hold voltage within VAR limits (gen, PV)
         *       3 - Hold voltage and angle (swing, V-Theta) (must always have one)
         *  Final voltage, p.u.
         *  Final angle, degrees.
         *  Load MW: Real power load
         *  Load MVAR: Reactive power load
         *  Generation MW: Real power generation
         *  Generation MVAR: Reactive power generation
         *  Base KV.
         *  Desired volts (pu). (This is desired remote voltage if this bus is controlling another bus.
         *  Maximum MVAR or voltage limit: Max reactive power (voltage).
         *  Minimum MVAR or voltage limit: Min reactive power (voltage).
         *  Shunt conductance G (per unit).
         *  Shunt susceptance B (per unit).
         *  Remote controlled bus number.
         *
         *  NOTES:
         *     Impedance: Z = R + jX (R = resistance, X = reactance)
         *     Admittance: is the inverse of impedance:  -Y = G + jB (G = conductance; B = susceptance).
         */
        IEEEBus(int busNumber, const std::string &busName, const std::string &busVoltageType, int loadFlowAreaNumber,
                int lossZoneNumber, int busType, double finalVoltagePU, double finalAngleDegrees, double loadMW,
                double loadMVAR, double generationMW, double generationMVAR, double baseKV, double desiredVoltsPU,
                double maximumMVAR, double minimumMVAR, double shuntConductancePU, double shuntSusceptancePU,
                int remoteControlledBusNumber) : busNumber(busNumber), busName(busName), busVoltageType(busVoltageType),
                                                 loadFlowAreaNumber(loadFlowAreaNumber), lossZoneNumber(lossZoneNumber),
                                                 busType(busType), finalVoltagePU(finalVoltagePU),
                                                 finalAngleDegrees(finalAngleDegrees), loadMW(loadMW),
                                                 loadMVAR(loadMVAR), generationMW(generationMW),
                                                 generationMVAR(generationMVAR), baseKV(baseKV),
                                                 desiredVoltsPU(desiredVoltsPU), maximumMVAR(maximumMVAR),
                                                 minimumMVAR(minimumMVAR), shuntConductancePU(shuntConductancePU),
                                                 shuntSusceptancePU(shuntSusceptancePU),
                                                 remoteControlledBusNumber(remoteControlledBusNumber) { }


        int getBusNumber() const {
            return busNumber;
        }

        int getLoadFlowAreaNumber() const {
            return loadFlowAreaNumber;
        }

        int getLossZoneNumber() const {
            return lossZoneNumber;
        }

        int getBusType() const {
            return busType;
        }

        const std::string &getBusName() const {
            return busName;
        }

        const std::string &getBusVoltageType() const {
            return busVoltageType;
        }

        double getFinalVoltagePU() const {
            return finalVoltagePU;
        }

        double getFinalAngleDegrees() const {
            return finalAngleDegrees;
        }

        double getLoadMW() const {
            return loadMW;
        }

        double getLoadMVAR() const {
            return loadMVAR;
        }

        double getGenerationMW() const {
            return generationMW;
        }

        double getGenerationMVAR() const {
            return generationMVAR;
        }

        double getBaseKV() const {
            return baseKV;
        }

        double getDesiredVoltsPU() const {
            return desiredVoltsPU;
        }

        double getMaximumMVAR() const {
            return maximumMVAR;
        }

        double getMinimumMVAR() const {
            return minimumMVAR;
        }

        double getShuntConductancePU() const {
            return shuntConductancePU;
        }

        double getShuntSusceptancePU() const {
            return shuntSusceptancePU;
        }

        double getRemoteControlledBusNumber() const {
            return remoteControlledBusNumber;
        }

        std::string to_string() const {
            return "Bus " + busName + "(id=" + std::to_string(busNumber) + ")"
                   + " load= " + std::to_string(loadMW) + " MW"
                   + " gen= "  + std::to_string(generationMW) + " MW"
                   + " G= " + std::to_string(shuntConductancePU)
                   + " B= " + std::to_string(shuntSusceptancePU);
        }

    private:

        int busNumber, loadFlowAreaNumber, lossZoneNumber, busType;
        std::string busName, busVoltageType;
        double finalVoltagePU, finalAngleDegrees, loadMW, loadMVAR, generationMW, generationMVAR,
                baseKV, desiredVoltsPU, maximumMVAR, minimumMVAR, shuntConductancePU,
                shuntSusceptancePU, remoteControlledBusNumber;
    };
}


#endif //D_AGC_DR_IEEEBUS_H
