//
// Created by Ferdinando Fioretto on 10/31/15.
//

#include <sstream>
#include <fstream>
#include <iostream>
#include <vector>

#include "Problem.h"
#include "Types.h"
#include "linear_algebra.hpp"
#include "string_utils.hpp"

using namespace misc_utils;
using namespace misc_utils::string_utils;

Problem::Problem(std::string busFilename, std::string agcFilename) {

    std::ifstream infileBus(busFilename, std::ios::in | std::ios::binary);
    std::ifstream infileData(agcFilename, std::ios::in | std::ios::binary);

    if (infileBus && infileData) {
        std::string busLine, agcParamLine, trash;
        readHorizon(infileData);

        do {
            std::getline(infileBus, busLine);
        } while (busLine.find("BUS DATA") != 0);

        // Creating BUS Agent:
        while( std::getline(infileBus, busLine) ) {
            // one line = one agent load or generator
            if (busLine.find("-999") == 0) break;
            std::stringstream busData(busLine);

            int busId, isDispatchable, isSlack, isReference;
            char busType;
            busData >> busId >> busType >> isSlack >> isReference >> isDispatchable;
            agcParamLine = getBusLine(infileData, busId, busType);

            // This is done to shift all buses to 0 (typically start from 1)
            busId -= 1;
            if (powerNetwork.find(busId) == getPowerNetwork().end())
                powerNetwork[busId] = std::make_shared<BusAgent>(busId, isDispatchable, isSlack, isReference);
            BusAgent::ptr busAgent = powerNetwork[busId];

            if (busType == 'G') {
                readGenerator(busLine, agcParamLine, busAgent);
            } else if (busType == 'L') {
                readLoad(busLine, agcParamLine, busAgent);
            }
        }

        for (auto& kv: powerNetwork) {
            if (kv.second->getGeneratorVariables().empty()) {
                // Insert Dummy Generation, if no genertion at this bus -- used in CostTable Initialization.
                for (int t = 0; t < Problem::horizon; t++)
                    kv.second->addGenerator(std::make_shared<GeneratorVariable>(std::vector<power_t>(1,0), 0, 0, 0, 0, 0));
            }

            if (kv.second->getLoadVariables().empty()) {
                // Insert Dummy Load, if no load at this bus -- used in CostTable Initialization.
                for (int t = 0; t < Problem::horizon; t++)
                    kv.second->addLoad(std::make_shared<LoadVariable>(0, std::vector<power_t>(1,0), 0, 0, 0));
            }
        }

        do {
            std::getline(infileBus, busLine);
        } while (busLine.find("BRANCH DATA") != 0);

        // Creating BRANCHES:
        while( std::getline(infileBus, busLine) ) {
            if (busLine.find("-999") == 0) break;
            std::stringstream branchData(busLine);

            int busTopID, busZID;
            double resistance, reactance, limitMW;
            branchData >> busTopID >> busZID >> resistance >> reactance >> limitMW;

            busTopID -= 1;
            busZID -= 1;

            auto busTop = Problem::powerNetwork[busTopID];
            auto busZ = Problem::powerNetwork[busZID];
            bool outgoing = true;
            auto flowTop = std::make_shared<FlowVariable>(busTopID, busZID, -limitMW, limitMW, resistance,
                                                          reactance, outgoing);
            busTop->addNeighbor(busZ, flowTop);

            auto flowZ = std::make_shared<FlowVariable>(busZID, busTopID, -limitMW, limitMW, resistance,
                                                        reactance, !outgoing);
            busZ->addNeighbor(busTop, flowZ);
        }

        computeShiftFactor();

    } else {
        throw(std::runtime_error("File " + busFilename + " not found"));
    }
}


void Problem::readHorizon(std::ifstream& infileData) {

    infileData.seekg (0, infileData.beg);
    std::string line;
    do {
        std::getline(infileData, line);
    } while (line.find("PROBLEM DATA") != 0);
    std::getline(infileData, line);
    std::stringstream data(line);

    data >> Problem::horizon;
    double prob;
    for (int i = 0; i < Problem::horizon; i++) {
        data >> prob;
        Problem::probabilities.push_back(prob);
    }
}


void Problem::readGenerator(const std::string& busDataStr, const std::string& busParamsStr, BusAgent::ptr busAgent) {

    busAgent->setGenerator();

    std::stringstream busData(busDataStr);
    std::stringstream busParams(busParamsStr);
    std::string trash;

    power_t dmin, dmax, dint, ramp, pozMin, pozMax;
    std::vector<power_t> pozMinList;
    std::vector<power_t> pozMaxList;
    std::vector<power_t> domList;
    int nPoz;
    busData >> trash >> trash >> trash >> trash >> trash;
    busData >> dmin >> dmax >> dint >> ramp >> nPoz;

    // Read Generator data - including POZ intervals
    for (int i = 0; i < nPoz; i++) {
        busData >> pozMin >> pozMax;
        pozMinList.push_back(pozMin);
        pozMaxList.push_back(pozMax);
    }

    // Populate generator domain, excluding POZ intervals
    for (power_t p = dmin; p <= dmax; p += dint) {
        if (nPoz == 0) {
            domList.push_back(p);
        } else {
            if (p < pozMinList[0]) {
                domList.push_back(p);
            } else {
                for (int i = 1; i < nPoz; i++) {
                    if (p > pozMaxList[i - 1] && p < pozMinList[i]) {
                        domList.push_back(p);
                        break;
                    }
                }
                if (p > pozMaxList.back()) {
                    domList.push_back(p);
                }
            }
        }
    }

    double cg1, cg2, cg3, cg4;
    power_t initalValue;
    busParams >> trash >> trash >> cg1 >> cg2 >> cg3 >> cg4 >> initalValue;

    for (int t = 0; t < Problem::horizon; t++) {
        busAgent->addGenerator(std::make_shared<GeneratorVariable>(domList, cg1, cg2, cg3, cg4, ramp));
    }
    if (initalValue >= 0) {
        busAgent->setInitialPowerInjected(initalValue);
    }
}


void Problem::readLoad(const std::string& busDataStr, const std::string& busParamsStr, BusAgent::ptr busAgent) {
    busAgent->setLoad();

    std::stringstream busData(busDataStr);
    std::stringstream busParams(busParamsStr);
    std::string trash;

    power_t dmin, dmax, dint;
    std::vector<power_t> domList;
    busData >> trash >> trash >> trash >> trash >> trash;
    busData >> dmin >> dmax >> dint;

    // Populate generator domain, excluding POZ intervals
    for (power_t p = dmin; p <= dmax; p += dint) {
        domList.push_back(p);
    }

    double cl1, cl2, predictedLoad;
    busParams >> trash >> trash >> cl1 >> cl2;

    for (int t = 0; t < Problem::horizon; t++) {
        busParams >> predictedLoad;
        if (t==0)
            busAgent->setInitialPowerWithdrawn(predictedLoad);
        busAgent->addLoad(std::make_shared<LoadVariable>(predictedLoad, domList, cl1, cl2, domList.back()));
    }
}


std::string Problem::getBusLine(std::ifstream& infileData, int busID, char busType) {
    infileData.seekg (0, infileData.beg);
    std::string line, trash;
    do {
        std::getline(infileData, line);
    } while (line.find("BUS DATA") != 0);

    int id; char type;
    while( std::getline(infileData, line) ) {
        std::stringstream data(line);
        data >> id >> type;
        if (id == busID && type == busType)
            return line;
        if (line.find("-999") == 0) break;
    }
    return nullptr;

}


void Problem::computeShiftFactor() {

    int size = Problem::getNbBuses();
    int slackBusID = 0, referenceBusID = 0;

    // Create Admittance Matrix (Y)
    for (auto &kv : Problem::powerNetwork) {
        auto bus = kv.second;
        bus->createAdmittanceMatrixRow(Problem::getNbBuses());

        if (bus->isSlackBus())
            slackBusID = bus->getBusID();
        if (bus->isReferenceBus())
            referenceBusID = bus->getBusID();
    }

//    int minBusID = 1000;
//    for (auto &kv : Problem::powerNetwork) {
//        minBusID = std::min(kv.second->getBusID(), minBusID);
//    }
//    slackBusID -= minBusID;
//    referenceBusID -= minBusID;

    // Create J matrix: is minus the imaginary part of the admittance matrix, (−B), with the column
    //   corresponding to the reference bus deleted.
    auto Jmatrix = lmatrix::alloc(size - 1, size - 1);

    for (int bi = 0, i = 0; bi < size; bi++) {
        if (bi == slackBusID) continue;
        auto Bmatrix = Problem::powerNetwork[bi]->getAdmittanceRow();
        for (int bj = 0, j = 0; bj < size; bj++) {
            if (bj == referenceBusID) continue;
            Jmatrix[i][j] = -Bmatrix[bj];
            j++;
        }
        i++;
    }

    //std::cout << "J=\n" << lmatrix::to_string(Jmatrix) << std::endl;
    auto Jinv = lmatrix::invert(Jmatrix);
    //std::cout << "J-1=\n" << lmatrix::to_string(Jinv) << std::endl;

    // Create Shift Factors
    // K Matrix:
    // rows    = (transmission lines (only one direction))
    // columns = all but reference bus (salta la colonna ref.)

    // Populate Outgoing Flows;
    for (auto &kv : Problem::powerNetwork) {
        for (auto &flow : kv.second->getFlowVariables()) {
            if (flow->isOutgoing()) {
                Problem::powerLines.push_back(flow);
            }
        }
    }

    auto Kmatrix = lmatrix::alloc(powerLines.size(), powerNetwork.size() - 1);

    for (int bID = 0, b = 0; bID < size; bID++) { // for all buses
        if (bID == referenceBusID) continue;

        auto bus = Problem::powerNetwork[bID];

        for (int f = 0; f < Problem::powerLines.size(); f++) {
            auto &flow = Problem::powerLines[f];
            // flow f does not involve this bus b
            int bTop = flow->getBusTopID();
            int bZ = flow->getBusZID();
            if (bTop != bID && bZ != bID)
                continue;

            double Bij = Problem::powerNetwork[bTop]->getAdmittanceRow()[bZ];
            Kmatrix[f][b] = (bTop == bID) ? Bij  // outgoing
                                          : -Bij; // incoming
        }
        b++;
    }

    //std::cout << "K= \n" << lmatrix::to_string(Kmatrix) << std::endl;
    // Shift Factor Matrix
    auto CMatrix = lmatrix::prod(Kmatrix, Jinv);
    //std::cout << lmatrix::to_string(CMatrix) << std::endl;

    for (int f = 0; f < Problem::powerLines.size(); f++) {
        auto &flow = Problem::powerLines[f];
        flow->setShiftFactors(CMatrix[f]);

        int zID = flow->getBusZID();
        for (auto inv_flow : Problem::powerNetwork[zID]->getFlowVariables()) {
            inv_flow->setShiftFactors(CMatrix[f]);
        }
    }

    auto CMatrixT = lmatrix::transpose(CMatrix);
    for (int bID = 0, b = 0; bID < size; bID++) { // for all buses
        auto bus = Problem::powerNetwork[bID];
        if (bID == slackBusID) {
            bus->setShiftFactors(std::vector<double>(Problem::powerLines.size(), 0.0));
        }
        else {
            bus->setShiftFactors(CMatrixT[b++]);
        }
    }
}
