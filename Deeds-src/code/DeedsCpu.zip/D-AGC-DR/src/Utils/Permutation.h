//
// Created by Ferdinando Fioretto on 11/6/15.
//

#ifndef D_AGC_DR_PERMUTATION_H
#define D_AGC_DR_PERMUTATION_H

#include <memory>
#include <vector>
#include <string>
#include <iostream>
#include <cmath>

#include "string_utils.hpp"

using namespace misc_utils;

namespace combinatorics {

    template <class T>
    class Permutation {
    public:
        typedef std::shared_ptr<Permutation> ptr;
        typedef std::vector<std::vector<T>> Permutations;

        Permutation(std::vector<T> values, int k, T limit=std::numeric_limits<T>::max())
                : values(values), k(k), limit(limit){
            tmpValues.resize(k, 0);
            level = 0;
            generate();
         }

        std::vector<std::vector<T>>& getPermutations() {
            return permutations;
        }

        size_t size() const {
            return permutations.size();
        }

        inline
        void generate() {
            if (level == k) {
                permutations.push_back(tmpValues);
                return;
            }

            for (int i = 0; i < values.size(); i++) {
                tmpValues[level++] = values[i];
                // if (i>0 && unary_op(binary_op(tmpValues[i-1], tmpValues[i])))
                if (level <= 1 || std::abs(tmpValues[level-2] - tmpValues[level-1]) <= limit)
                    generate();
                level--;
            }
        }

        std::string to_string() const {
            std::string res;
            for (auto& v : permutations) {
                res += string_utils::to_string(v) + "\n";
            }
            return res;
        }

    private:
        std::vector<T> values;
        int k;
        std::vector<std::vector<T>> permutations;

        int level;
        std::vector<T> tmpValues;
        T limit;
    };

};


#endif //D_AGC_DR_PERMUTATION_H
