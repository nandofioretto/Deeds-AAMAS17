//
// Created by Ferdinando Fioretto on 10/31/15.
//

#ifndef D_AGC_DR_GENERATORVARIABLE_H
#define D_AGC_DR_GENERATORVARIABLE_H

#include <vector>
#include <cstdlib>
#include <cmath>
#include <algorithm>

#include "Types.h"

class GeneratorVariable {

public:
    typedef std::shared_ptr<GeneratorVariable> ptr;

    GeneratorVariable(const std::vector<power_t> &values, double alpha, double beta, double epsilon, double phi,
                      double rampDelta)
            : value(-1), values(values), alpha(alpha), beta(beta), epsilon(epsilon), phi(phi), rampDelta(rampDelta) {
        std::sort(GeneratorVariable::values.begin(), GeneratorVariable::values.end());
        min = values.front();
        max = values.back();
    }

    cost_t getCostIdx(int elemIdx) {
        return getCost(values[elemIdx]);
    }

    cost_t getCost(power_t p) {
        return (alpha * p) + (beta * p * p) + std::abs(epsilon * sin(phi * (min - p)));
    }

    cost_t getCost() {
        return getCost(value);
    }


    power_t &operator[](std::size_t idx) {
        return values[idx];
    }

    const power_t &operator[](std::size_t idx) const {
        return values[idx];
    }

    power_t getMin() const {
        return min;
    }

    power_t getMax() const {
        return max;
    }

    const std::vector<power_t> &getValues() const {
        return values;
    }

    double getRampDelta() const {
        return rampDelta;
    }

    power_t getValue() const {
        return value;
    }

    void setValue(power_t value) {
        GeneratorVariable::value = value;
    }


    double getAlpha() const {
        return alpha;
    }

    double getBeta() const {
        return beta;
    }

    double getEpsilon() const {
        return epsilon;
    }

    double getPhi() const {
        return phi;
    }

    std::string to_string() const {
        std::string ret = "Generator (" + std::to_string(alpha) + "," + std::to_string(beta)
                          + "," + std::to_string(epsilon) + "," + std::to_string(phi) + ")";
        ret += " range: [";
        for (power_t p : values)
            ret += std::to_string(p) + ",";
        ret += "]MW";
        ret += " ramp: (" + std::to_string(rampDelta) + ") MW";
        return ret;
    }


private:
    power_t min, max;
    std::vector<power_t> values;
    power_t value;

    // Parameters:
    double alpha, beta, epsilon, phi;
    double rampDelta;
};


#endif //D_AGC_DR_GENERATORVARIABLE_H
