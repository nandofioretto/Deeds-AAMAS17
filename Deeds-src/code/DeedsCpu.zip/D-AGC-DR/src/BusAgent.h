//
// Created by Ferdinando Fioretto on 10/31/15.
//

#ifndef D_AGC_DR_BUSAGENT_H
#define D_AGC_DR_BUSAGENT_H


#include <vector>
#include <string>
#include <iostream>
#include "LoadVariable.h"
#include "GeneratorVariable.h"
#include "FlowVariable.h"

class BusAgent {

public:
    typedef std::shared_ptr<BusAgent> ptr;

    BusAgent() { }

    BusAgent(int busID, bool dispatchable=true, bool slackBus=false, bool referenceBus=false)
            : busID(busID), dispatchable(dispatchable), slackBus(slackBus), referenceBus(referenceBus),
              generator(false), load(false),
            initialPowerInjected(0),  initialPowerWithdrawn(0)
    { }

    void addLoad(LoadVariable::ptr load) {
        loadVariables.push_back(load);
    }

    void addGenerator(GeneratorVariable::ptr generator) {
        generatorVariables.push_back(generator);
    }

    void addNeighbor(BusAgent::ptr bus, FlowVariable::ptr flow) {
        if (BusAgent::getBusID() != flow->getBusTopID() || bus->getBusID() != flow->getBusZID())
            throw(std::runtime_error("Flow Constraint Top Bus not matching"));

        neighborsBuses.push_back(bus);
        flowVariables.push_back(flow);
    }

    int getNbBusNeighbors() const {
        return neighborsBuses.size();
    }

    BusAgent::ptr getBusNeighbor(int i) {
        return neighborsBuses[i];
    }

    int getBusID() const {
        return busID;
    }

    const std::string &getBusName() const {
        return busName;
    }

    const std::vector<double> &getAdmittanceRow() const {
        return admittanceRow;
    }

    const std::vector<ptr> &getNeighborsBuses() const {
        return neighborsBuses;
    }

    const std::vector<LoadVariable::ptr> &getLoadVariables() const {
        return loadVariables;
    }

    const LoadVariable::ptr& getLoadVariable(int time) const {
        return loadVariables[time];
    }

    const std::vector<GeneratorVariable::ptr> &getGeneratorVariables() const {
        return generatorVariables;
    }

    const GeneratorVariable::ptr& getGeneratorVariable(int time) const {
        return generatorVariables[time];
    }

    const std::vector<FlowVariable::ptr> &getFlowVariables() const {
        return flowVariables;
    }

    bool isDispatchable() const {
        return dispatchable;
    }

    bool isSlackBus() const {
        return slackBus;
    }

    bool isReferenceBus() const {
        return referenceBus;
    }

    void createAdmittanceMatrixRow(int nBuses);


    const std::vector<double> &getShiftFactors() const {
        return shiftFactors;
    }

    double getShiftFactor(int i) const {
        return shiftFactors[i];
    }

    void setShiftFactors(const std::vector<double> &shiftFactors) {
        BusAgent::shiftFactors = shiftFactors;
    }


    power_t getInitialPowerInjected() const {
        return initialPowerInjected;
    }

    void setInitialPowerInjected(power_t initialPowerInjected) {
        std::cout << "Gen " << getBusID() << " initial MW: " << initialPowerInjected << "\n";
        BusAgent::initialPowerInjected = initialPowerInjected;
    }

    power_t getInitialPowerWithdrawn() const {
        return initialPowerWithdrawn;
    }

    void setInitialPowerWithdrawn(power_t initialPowerWithdrawn) {
        std::cout << "Load " << getBusID() << " initial MW: " << initialPowerWithdrawn << "\n";
        BusAgent::initialPowerWithdrawn = initialPowerWithdrawn;
    }

    bool isLoad() const {
        return load;
    }

    void setLoad(bool isLoad=true) {
        BusAgent::load = isLoad;
    }

    bool isGenerator() const {
        return generator;
    }

    void setGenerator(bool isGenerator=true) {
        BusAgent::generator = isGenerator;
    }

    std::string to_string() const {
        std::string ret = "Bus " + std::to_string(busID);
        if (dispatchable) ret += " dispatchable ";
        if (slackBus) ret += " slack ";
        ret += "\n";
        for (auto load : loadVariables)
            ret += "\t" + load->to_string() + "\n";

        for (auto generator : generatorVariables)
            ret += "\t" + generator->to_string() + "\n";

        for (auto line : flowVariables)
            ret += "\t" + line->to_string() + "\n";

        ret += "B_" + std::to_string(busID) + ": ";

        for (auto y : admittanceRow)
            ret += std::to_string(y) + " ";

        ret += "\n K_" + std::to_string(busID) + ": ";
        for (auto s : shiftFactors)
            ret += std::to_string(s) + " ";

        return ret;
    }

protected:
    int busID;
    std::string busName;
    bool dispatchable;
    bool slackBus;
    bool referenceBus; // known angles
    bool generator;
    bool load;

    power_t initialPowerInjected;
    power_t initialPowerWithdrawn;

    std::vector<BusAgent::ptr> neighborsBuses;
    std::vector<LoadVariable::ptr> loadVariables;
    std::vector<GeneratorVariable::ptr> generatorVariables;
    std::vector<FlowVariable::ptr> flowVariables; // flow (i,j) with i=Tap agent.
    std::vector<double> admittanceRow; // the row of the admittance matrix associated to this agent.

    // Todo: Get all topology with flowVariables ID, link flowVariables to Problem Class
    // The shift Factor column of the C-matrix associated to this bus.
    // Contains the multipliers for the flows, affected by the net power output of this bus.
    std::vector<double> shiftFactors;

};

#endif //D_AGC_DR_BUSAGENT_H
