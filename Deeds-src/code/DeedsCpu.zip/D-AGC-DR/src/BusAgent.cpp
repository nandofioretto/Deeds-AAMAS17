//
// Created by Ferdinando Fioretto on 10/31/15.
//

#include <complex>

#include "BusAgent.h"

// admittance for line ij: y_ij = 1 / zij
void BusAgent::createAdmittanceMatrixRow(int nBuses) {

    admittanceRow.resize(nBuses, 0.0);

    for (int i = 0; i < BusAgent::getNbBusNeighbors(); i++) {
        auto flow = flowVariables[i];
        int iID = flow->getBusTopID();  // this agent;
        int jID = flow->getBusZID();    // other agent;

        std::complex<double> admittance_ij = 1.0 / flow->getImpedance(); // y_ij

        // off-diagonal terms Yij = negative line admittance between i and j bus.
        admittanceRow[jID] = -admittance_ij.imag();

        // diagonal Term: Yii = sum of all connected line admittances to this bus.
        admittanceRow[iID] += admittance_ij.imag();
    }

}