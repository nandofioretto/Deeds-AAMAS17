//
// Created by Ferdinando Fioretto on 11/3/15.
//

#ifndef D_AGC_DR_DPOPERATIONS_H
#define D_AGC_DR_DPOPERATIONS_H

#include <map>
#include <vector>
#include <utils.hpp>
#include <string_utils.hpp>

#include "Types.h"

using namespace misc_utils;
using namespace misc_utils::utils;

namespace DP {
    // Key: 2H elements (for <gen_1,...,gen_h, load_1,...,load_h>  at each time t=0...H-1))
    // Value: A vectors ach containing all line flows values f_1^1, .. f_F^1, ... f_1^h, ..., f_F^h
    //        and the cost of this combination.
    typedef std::map<std::vector<power_t>, std::vector<cost_t>> HCostTable;
    // Key:   2H elements (as above)
    // Value: 2H values for the elements in the key
    typedef std::map<std::vector<power_t>, std::vector<power_t>> HValueTable;


    // Ramp constraints (check if all generator values are within limits) (g_t - g_t+1) <= rampGen
    // Not necesary here, already handled in the initialization step at each agent.
    //                bool rampSat = check_cmp_if(p.begin(), p.begin()+H, p.begin()+1,
    //                                            utils::norm<power_t>(), bind2nd(std::less_equal<power_t>(), rampGen));
    //                if (!rampSat) continue;
    //                rampSat = check_cmp_if(p.begin()+H, p.end(), p.begin()+H+1,
    //                                       utils::norm<power_t>(), bind2nd(std::less_equal<power_t>(), rampLoad));
    //                if (!rampSat) continue;

    /**
     * Join and Project operations for multiple time-steps with penality constraint and ramp rate constraints.
     * TableA is the costTable of this agent.
     * TableB is the costTable received from some other agent.
     * flowLimits: the vector of flow constraint limits.
     * wfl: the weight for the flow limit penalty.
     * mfl: the congestion for the flow limit penalty.
     * rampGen, rampLoad: the ramp costraints for generator and load.
     */
    inline
    HCostTable join(HValueTable& valueTable, const HCostTable& tableA, const HCostTable& tableB,
                    const std::vector<double>& flowLimits, std::vector<double> wDiscountedFlowPenality,
                    double flowCongestionLimit, double rampGen, double rampLoad) {
        HCostTable tableC;

        assert(!tableA.empty());

        int H = tableA.begin()->first.size() / 2;
        int nFlows = flowLimits.size();
        std::vector<power_t> p(2*H,0);
        std::vector<double> flows(tableA.begin()->second.size(), 0);
        std::vector<double> residualFlows(tableA.begin()->second.size(), 0);
        int costIdx = tableA.begin()->second.size()-1;

        for (auto& kva : tableA) {
            for (auto & kvb : tableB) {
                p = kva.first + kvb.first;
                flows = kva.second + kvb.second;
                cost_t cost = flows[costIdx];
                residualFlows = abs(flows / flowLimits);   // Todo: speedup

                // Flow Penalities (Constraint)
                cost_t penality = 0;
                for (int t=0; t<H; t++) {
                    penality += wDiscountedFlowPenality[t] *
                            sum_if_geq(residualFlows.begin() + t*nFlows,
                                       residualFlows.begin() + (t+1)*nFlows, flowCongestionLimit);
                }
                flows[costIdx] = cost - penality;

                HCostTable::iterator it = tableC.find(p);
                if (it == tableC.end() || flows[costIdx] > it->second.at(costIdx)) {
                    tableC[p] = flows;
                    valueTable[p] = kva.first;
                }
            }
        }
        return tableC;
    }

    inline
    void join(HCostTable& joinTable, HValueTable& valueTable, const HCostTable & costTable,
              const std::vector<double>& flowLimits, std::vector<double> wDiscountsFlowPenalities,
              double flowCongestionLimit, double rampGen, double rampLoad) {
        HCostTable T = join(valueTable, costTable, joinTable, flowLimits, wDiscountsFlowPenalities,
                            flowCongestionLimit, rampGen, rampLoad);
        joinTable.swap(T);
    }


    /**
     * Constructs a dummy table containing only one elmeent (0,0) with all costs = 0s.
     */
    inline
    HCostTable dummyTable(int size, int H) {
        HCostTable T;
        T[std::vector<power_t>(2*H,0)].resize(size);
        return T;
    }

    inline
    bool isSat(const std::tuple<std::vector<power_t>, std::vector<power_t>>& valTuple) {
        return (std::get<0>(valTuple).size() > 0 && std::get<0>(valTuple).front() != -1);
    }

    inline std::string to_string(HCostTable table) {
        std::string ret = " CostTable:\n";
        for (auto& kv : table) {
            ret += string_utils::to_string(kv.first) + " : " + string_utils::to_string(kv.second) + "\n";
        }
        return ret;
    }

//    inline std::string to_string(HValueTable table) {
//        std::string ret = " ValueTable:\n";
//        for (auto& kv : table) {
//            ret += string_utils::to_string(kv.first) + " : " + string_utils::to_string(kv.second) + "\n";
//        }
//        return ret;
//    }

};

#endif //D_AGC_DR_DPOPERATIONS_H
