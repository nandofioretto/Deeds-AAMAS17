#include <Utils/Timer.h>
#include "IDPOP/IDPOPSolver.h"
#include "string_utils.hpp"
#include "Types.h"

//#define VERBOSE
using namespace misc_utils;

void IDPOPSolver::updateFlowPenaltyParams(double &alpha, double &prevAlpha, double &alphaLb, double &alphaUb,
                                          double &alphaErr, double& bestSatAlpha, bool isSat,
                                          cost_t& currUtil, cost_t& prevUtil, double& utilIncr) {

    utilIncr = isSat ? std::abs(currUtil - prevUtil) / std::max(currUtil, prevUtil) : 1.0;
    if (isSat) prevUtil = currUtil;

    // Update Best Sat Penalty
    if (isSat) bestSatAlpha = alpha;
    // Update Bounds
    alphaLb = isSat ? alphaLb :   alpha;
    alphaUb = isSat ? alpha   : alphaUb;
    // update Error
    alphaErr = isSat ? ((alphaUb - alphaLb) / alphaUb) : 1.0;

    double step = (std::abs(alpha - prevAlpha) / 2.0);
    prevAlpha = alpha;

    alpha = isSat ? (alpha - step)           // Sat
            : (alphaUb <= 0 ? alpha * 2      // Unsat: Never succedded
                            : alpha + step); // Unsat: succeded eariler.
}


void IDPOPSolver::solve() {

    // Todo: Set Ordering according to pseudo-tree.
    // Call first Agent, (leaf) - return Table
    auto orderedAgents = agents, orderedAgentsR = agents;
    auto rootAgent = orderedAgents.front();
    rootAgent->setRoot();
    orderedAgents.back()->setLeaf();
    std::reverse(orderedAgentsR.begin(), orderedAgentsR.end());

    std::tuple<std::vector<power_t>, std::vector<power_t>> valTuple;
    DP::HCostTable joinedTable;

//    std::cout << "time Horizon: " << Solver::getHorizon() << '\n';
//    for (auto agent : orderedAgentsR)
//        std::cout << "Agent " << agent->getBusID() << '\n' << DP::to_string(agent->getCostTable()) << '\n';
//    return;

    const int nAgents = orderedAgents.size();
    std::vector<Timer<>> utilPropagation(nAgents);
    std::vector<Timer<>> valuePropagation(nAgents);

    for (int time=0; time < Solver::getHorizon(); time += optHorizon) {
        std::cout << "Time " << time << "\n";
        // Todo: Remove some of these parameters as unnecessary
        double prevFlowPenalty = 0;
        double currFlowPenalty = IDPOPSolver::wFlowPenalty;
        double wFlowPenaltyLb = 0, wFlowPenaltyUb = -1;
        double wFlowPenaltyErr = 1.0, bestSatFlowPenalty = 0;
        cost_t currUtil = 0, prevUtil = 0;
        double utilStepImprovment = 0;
        int nSteps = 0;

        do {

            // Ensure to output a feasible solution, when breaking the loop
            if (nSteps > IDPOPSolver::nMaxSteps) {
                currFlowPenalty = bestSatFlowPenalty;
            }

            ////////////////////////////////////
            // UTIL (bottom up)
            ////////////////////////////////////
            utilPropagation[0].start();
            joinedTable = DP::dummyTable(optHorizon * branchesLimit.size() + 1, optHorizon);
            utilPropagation[0].pause();

            for (auto agent : orderedAgentsR) {
#ifdef VERBOSE
                std::cout << "UTIL Agent " << agent->getBusID() << "\n";
#endif
                utilPropagation[agent->getBusID()].start();
                agent->joinCostTables(joinedTable, currFlowPenalty, flowCongestionLimit);
                utilPropagation[agent->getBusID()].pause();

#ifdef VERBOSE
                std::cout << "joining Table of agent " << agent->getBusID() // << DP::to_string(agent->getCostTable()) << '\n';
                          << " Result in: \n" << DP::to_string(joinedTable) << std::endl;
#endif
            }

            valuePropagation[rootAgent->getBusID()].start();
            valTuple = rootAgent->extractValue(joinedTable, true);
            currUtil = rootAgent->getOptUtil();
            valuePropagation[rootAgent->getBusID()].pause();

            if (nSteps > nMaxSteps) break;
            updateFlowPenaltyParams(currFlowPenalty, prevFlowPenalty, wFlowPenaltyLb, wFlowPenaltyUb, wFlowPenaltyErr,
                                    bestSatFlowPenalty, DP::isSat(valTuple), currUtil, prevUtil, utilStepImprovment);

#ifdef VERBOSE
            std::cout << "Time: " << time << " ITERATION " << nSteps << '/' << IDPOPSolver::nMaxSteps
            << " currPenalty: " << currFlowPenalty << "["<< wFlowPenaltyLb << "," << wFlowPenaltyUb << "]"
            << " err: " << wFlowPenaltyErr << '/' << maxFlowPenaltyErr
            << " best Alpha: " << bestSatFlowPenalty
            << " prev Util: " << prevUtil << " curr Util " << currUtil << " incr: " << utilStepImprovment << '\n';
            // std::cout << "Flows: " << string_utils::to_string(rootAgent->getBranchesFlows()) << '\n';
#endif
            nSteps++;
        } while (utilStepImprovment > maxFlowPenaltyErr &&
         nSteps <= nMaxSteps);

        assert(DP::isSat(valTuple));

        ////////////////////////////////////
        // VALUE (top down)
        ////////////////////////////////////
        rootAgent->setVariables(std::get<0>(valTuple), time);
#ifdef VERBOSE
        std::cout << "Flows: " << string_utils::to_string(rootAgent->getBranchesFlows()) << '\n';
        std::cout << "Limits " << string_utils::to_string(branchesLimit) << "\n";
        std::cout << "Root selected values: " << string_utils::to_string(std::get<0>(valTuple)) << "\n";
#endif
        for (auto agent : orderedAgents) {
            if (agent->isRoot()) continue;

            valuePropagation[agent->getBusID()].start();
            valTuple = agent->extractValue(std::get<1>(valTuple));
            agent->setVariables(std::get<0>(valTuple), time);
            valuePropagation[agent->getBusID()].pause();
#ifdef VERBOSE
            std::cout << "Agent " << agent->getBusID() <<": selected values: " << string_utils::to_string(std::get<0>(valTuple)) << "\n";
#endif
        }

        for (auto agent : orderedAgentsR) {
            utilPropagation[agent->getBusID()].start();
            agent->incrTime(optHorizon);
            agent->reinitialize();
            utilPropagation[agent->getBusID()].pause();
        }
    }

    std::cout << "UTIL : " << rootAgent->getOptUtil() << "\n";
    for (auto agent : orderedAgents) {
        std::cout << "Agent " << agent->getBusID()
        << " Util Propagation: " << utilPropagation[agent->getBusID()].getElapsed() << " ms \t"
        << "Value Propagation: " << valuePropagation[agent->getBusID()].getElapsed() << " ms \n";
    }
}