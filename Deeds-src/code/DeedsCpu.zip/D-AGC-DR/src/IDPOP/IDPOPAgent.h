//
// Created by Ferdinando Fioretto on 11/3/15.
//

#ifndef D_AGC_DR_IDPOPAGENT_H
#define D_AGC_DR_IDPOPAGENT_H

#include <map>
#include <iostream>
#include <functional>   // std::multiplies
#include <numeric>      // std::partial_sum

#include <string_utils.hpp>
#include "BusAgent.h"
#include "DPoperations.h"
#include "Types.h"

using namespace misc_utils;
using namespace misc_utils::utils;

class IDPOPAgent : public BusAgent {

public:
    typedef std::shared_ptr<IDPOPAgent> ptr;

    IDPOPAgent(BusAgent::ptr busAgent, std::vector<std::pair<int,int>> branchesID, std::vector<double> branchesLimits,
               int horizon, std::vector<double> probabilities, int optHorizon)
        : branches(branchesID), branchesLimits(branchesLimits), time(0), horizon(horizon), alpha_t(probabilities),
          optHorizon(optHorizon), root(false), leaf(false) {

        cumulativeAgentCost = 0;
        busID = busAgent->getBusID();
        busName = busAgent->getBusName();
        dispatchable = busAgent->isDispatchable();
        slackBus = busAgent->isSlackBus();
        referenceBus = busAgent->isReferenceBus();
        neighborsBuses = busAgent->getNeighborsBuses();
        loadVariables = busAgent->getLoadVariables();
        generatorVariables = busAgent->getGeneratorVariables();
        flowVariables = busAgent->getFlowVariables();
        admittanceRow = busAgent->getAdmittanceRow();
        shiftFactors = busAgent->getShiftFactors();

        generator  = busAgent->isGenerator();
        load       = busAgent->isLoad();
        initialPowerInjected  = busAgent->getInitialPowerInjected();
        initialPowerWithdrawn = busAgent->getInitialPowerWithdrawn();


//        alpha_t.resize(horizon, discount);
//        alpha_t[0] = 1;
//        std::partial_sum(alpha_t.begin(), alpha_t.end(), alpha_t.begin(), std::multiplies<double>());
    }

    // It fills the Agent CostTable (for a given horizon h).
    void initialize();

    void reinitialize();

    bool isRoot() const {
        return root;
    }

    void setRoot(bool root=true) {
        IDPOPAgent::root = root;
    }

    bool isLeaf() const {
        return leaf;
    }

    void setLeaf(bool leaf=true) {
        IDPOPAgent::leaf = leaf;
    }

    int getTime() const {
        return time;
    }

    void setTime(int t) {
        time = t;
    }

    void incrTime(int h=1) {
        time += h;
    }

    int getHorizon() const {
        return horizon;
    }

    int getOptHorizon() const {
        return optHorizon;
    }

    const cost_t getOptUtil() const {
        return root ? branchesFlows.back() : 0;
    }

    const std::vector<double> &getBranchesFlows() const {
        return branchesFlows;
    }

    /**
     * vector containing H generator values and H load values (for each of the H time steps)
     */
    void setVariables(std::vector<power_t> values, int time) {
        for (int t = 0; t < optHorizon; t++) {
            getGeneratorVariable(time+t)->setValue(values[t]);
            getLoadVariable(time+t)->setValue(values[t + optHorizon]);
        }
    }

    const DP::HCostTable& getCostTable() const {
        return costTableH;
    }

    const DP::HValueTable& getValueTable() const {
        return valueTableH;
    }

    /**
     * Joins Two cost Table received from an agent with the one of the current agent.
     * Includes flow congestion limit constraints.
     */
    void joinCostTables(DP::HCostTable& recvCostTable, double wFlowPenality, double flowCongestionLimit) {

        double genRamp  = getGeneratorVariable(time)->getRampDelta();
        double loadRamp = getLoadVariable(time)->getRampDelta();

        // Flow penalties (given in input) multiplied by the discount factor
        std::vector<double> wDiscountsFlowPenalities =
                std::vector<double>(alpha_t.begin() + time, alpha_t.begin() + time + optHorizon) * wFlowPenality;

        DP::join(recvCostTable, valueTableH, costTableH, branchesLimits, wDiscountsFlowPenalities,
                 flowCongestionLimit, genRamp, loadRamp);
    }

    /**
     * Extracts the value associated to a configuration.
     */
    std::tuple<std::vector<power_t>, std::vector<power_t>>
            extractValue(const std::vector<power_t>& p, bool checkFlowLimits=false) {
        return std::make_tuple(valueTableH[p], p - valueTableH[p]);
    }

    /**
     * Returns the best <gen_1,...,gen_h, load_1,...,load_h> power outputs associated to the
     * CostTableH with the best power differences \Delta<gen_1,...,gen_h, load_1,...,load_h> to
     * be used to match the next agent in the list.
     *
     * This function should only be called by the root agent.
     */
    std::tuple<std::vector<power_t>, std::vector<power_t>>
            extractValue(const DP::HCostTable& joinTable, bool checkFlowLimits=false);

    std::string to_string() const {
        std::string ret = "Agent " + std::to_string(getBusID()) + "\n";
//        }
        for (int t=0; t<horizon; t++) {
            ret += "\ttime[" + std::to_string(t) + "] gen: " +
                   std::to_string(getGeneratorVariable(t)->getValue()) + ", load: " +
                   std::to_string(getLoadVariable(t)->getValue()) + "\n";
        }
        return ret;
    }

private:
    int time, horizon, optHorizon;
    bool root, leaf;

    // <g_0,...,g_{h-1}, l_0,..,l_{h-1}> at this bus -> vector of (partial) flows; (no Utility).
    DP::HCostTable oriCostTableH;
    // <g_0,...,g_{h-1}, l_0,..,l_{h-1}> at this bus -> discounted utilities for all the partitioned horizon.
    DP::HCostTable oriFlowTableH;

    // <g_0,...,g_{h-1}, l_0,..,l_{h-1}> at this bus -> vector of (partial) flows; last position is the Utility.
    DP::HCostTable costTableH;
    DP::HValueTable valueTableH;

    // Holds the cost of the agents
    double cumulativeAgentCost;

    //double dicount;
    std::vector<double> alpha_t;
    std::vector<std::pair<int,int>> branches;
    std::vector<double> branchesLimits;
    std::vector<double> branchesFlows;
};


#endif //D_AGC_DR_IDPOPAGENT_H
