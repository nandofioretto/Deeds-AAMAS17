//
// Created by Ferdinando Fioretto on 11/3/15.
//

#include <functional>
#include <vector>
#include <numeric>

#include <string_utils.hpp>
#include <Utils/Permutation.h>

#include "IDPOPAgent.h"

#define INIT_EQ
//#define VERBOSE

using namespace misc_utils::utils;

// Todo: A lot of operations here can all be sped up!
void IDPOPAgent::initialize() {
#ifdef VERBOSE
    std::cout << "==================================\n";
    std::cout << "Initializing A" << getBusID() << '\n';
    std::cout << "==================================\n";
#endif
    auto gen  = getGeneratorVariable(time);
    auto load = getLoadVariable(time);
    int nFlows = branches.size();
    std::vector<double> flows(optHorizon * nFlows + 1, 0);

    std::vector<power_t> predictedLoads(optHorizon);
    for (int t = 0; t < optHorizon; t++)
        predictedLoads[t] = getLoadVariable(t)->getPredicted();

    double rampGen  = gen->getRampDelta();
    double rampLoad = load->getRampDelta();

    // Generate Feasible combo for generators and loads, of required time horizon H
    combinatorics::Permutation<power_t> genH(gen->getValues(), optHorizon, rampGen);
    combinatorics::Permutation<power_t> loadH(load->getValues(), optHorizon, rampLoad);

    // For every value of Generator,
    std::vector<power_t> pgl(2* optHorizon,0);
    int nStepsHorizon = (horizon / optHorizon);     // todo: check optHorizon divides horizon exactly
    for (const auto& pgH : genH.getPermutations()) {

        // Populate generation costs of this combination for all the horizon
        std::vector<cost_t> genCosts(nStepsHorizon, 0);
        for (int i = 0; i < nStepsHorizon; i++) {
            int t = i*optHorizon;
            int j = 0;
            while (t < std::min(horizon, (i+1)*optHorizon)) {
                genCosts[i] += alpha_t[t++] * gen->getCost( pgH[j++] );
            }
        }

        std::copy(pgH.begin(), pgH.end(), pgl.begin());
        // For every value of Load,
        for (const auto& plH : loadH.getPermutations()) {

            // Populate load costs of this combination for all the horizon
            std::vector<cost_t> loadCosts(nStepsHorizon, 0);
            for (int i = 0; i < nStepsHorizon; i++) {
                int t = i*optHorizon;
                int j = 0;
                while (t < std::min(horizon, (i+1)*optHorizon)) {
                    loadCosts[i] += alpha_t[t++] * load->getCost(plH[j++]);
                }
            }

            std::copy(plH.begin(), plH.end(), pgl.begin() + optHorizon);

            std::vector<cost_t> cost = loadCosts - genCosts;
            auto netPower = (pgH - plH);           // speedup
//            std::cout << "A" <<  getBusID() << "(" << string_utils::to_string(pgl) << ") : " << string_utils::to_string(flows)
//                      << string_utils::to_string(cost) <<'\n';

            for (int t = 0; t < optHorizon; t++) {
                for (int i = 0; i < nFlows; i++) {
                    flows[t*nFlows + i] = BusAgent::getShiftFactor(i) * netPower[t];
                }
            }
            // flows.back() = cost;
            oriFlowTableH[pgl] = flows; // contains flows of only current optHorizon
            oriCostTableH[pgl] = cost;  // contains costs of all horizons (partitioned in chunks of optHorizons)
        }
    }

    // Populate the relevant data structures
    for (auto& kv : IDPOPAgent::oriFlowTableH) {

        auto gens  = kv.first.begin();
        auto loads = kv.first.begin() + optHorizon;

#ifdef INIT_EQ
        // Check predicted load constraints (load produced is == than the predicted load) (for first time step
        if (isGenerator() && gens[0] !=  BusAgent::getInitialPowerInjected())
            continue;
        if (isLoad() && loads[0] != BusAgent::getInitialPowerWithdrawn())
            continue;
#endif
        // Check predicted load constraints (load produced is <= than the predicted load)
        if (!utils::leq(loads, loads + optHorizon, predictedLoads.begin()))
            continue;  // pruning

        costTableH.insert(kv);
        costTableH[kv.first].back() = oriCostTableH[kv.first].at(0);  // 0 is current time

#ifdef VERBOSE
        std::cout << "A" <<  getBusID() << "(" << string_utils::to_string(kv.first) << ") : "
                  << string_utils::to_string(kv.second) << "::: "
                  << std::to_string(oriCostTableH[kv.first].at(0)) << '\n';
#endif
    }
}

// Need a special case for T = 0;
void IDPOPAgent::reinitialize() {
#ifdef VERBOSE
    std::cout << "============================\n";
    std::cout << "Reinitializing Agent " << getBusID() << "\n";
    std::cout << "============================\n";
#endif
    if (time == 0 || time >= horizon) return; // skip initialization for the first time-step
    int thisOptStep = (time / optHorizon);

    costTableH.clear();
    valueTableH.clear();   // Todo: Optimize (check if necessary)

    double genValue  = getGeneratorVariable(time-1)->getValue();
    double genRamp   = getGeneratorVariable(time-1)->getRampDelta();
    double loadValue = getLoadVariable(time-1)->getValue();
    double loadRamp  = getLoadVariable(time-1)->getRampDelta();

    std::vector<power_t> predictedLoads(optHorizon);
    for (int t = 0; t < optHorizon; t++)
        predictedLoads[t] = getLoadVariable(time+t)->getPredicted();

    for (auto& kv : IDPOPAgent::oriFlowTableH) {
        // Check ramp constraints:
        if (std::abs(genValue  - kv.first[0]) > genRamp) continue;
        if (std::abs(loadValue - kv.first[optHorizon]) > loadRamp) continue;

        // Check predicted load constraints (load produced is <= than the predicted load)
        auto loads = kv.first.begin() + optHorizon;

        if (isLoad()) {
            if (isDispatchable()) {
                if (!utils::leq(loads, loads + optHorizon, predictedLoads.begin()))
                    continue;
            }
            else {
                if (!utils::eq(loads, loads + optHorizon, predictedLoads.begin()))
                    continue;
            }
        }

        costTableH.insert(kv);
        costTableH[kv.first].back() = oriCostTableH[kv.first].at(thisOptStep);

#ifdef VERBOSE
        std::cout << "A" <<  getBusID() << "(" << string_utils::to_string(kv.first) << ") : "
               << string_utils::to_string(kv.second) << "::: "
                << std::to_string(oriCostTableH[kv.first].at(0)) << '\n';
#endif
    }
}


std::tuple<std::vector<power_t>, std::vector<power_t>>
IDPOPAgent::extractValue(const DP::HCostTable& joinTable, bool checkFlowLimits) {

    int costIdx = costTableH.begin()->second.size()-1;
    auto bestValue = std::vector<power_t>(2* optHorizon, -1);
    auto bestValueDiff = std::vector<power_t>(2* optHorizon, -1);
    cost_t bestCost = std::numeric_limits<power_t>::lowest();
    std::vector<flow_t> bestFlow;

    for (auto& kv : joinTable) {
        // Ensure Constraint Sum Loads = Sum Generation is SAT
        // Todo: Change here if slack bus can carry as much power as we wish.
        if (std::equal (kv.first.begin(), kv.first.begin()+ optHorizon, kv.first.begin()+ optHorizon)) {

            auto& flows = kv.second;
            // std::cout << "Equal gen/loads: " << string_utils::to_string(kv.first) << " ::: " << string_utils::to_string(kv.second) << '\n';
            // std::cout << "flow cost: " << flows[costIdx] << " best cost: " << bestCost << "\n";
            if (flows[costIdx] > bestCost) {
                //std::cout << "best cost found\n";
                // Ensure Flow constraints are SAT
                if (checkFlowLimits && !utils::rep_leq(flows.begin(), flows.end()-1,
                                                       branchesLimits.begin(), branchesLimits.end())) {
//                    std::cout << "Flow violation\n";
//                    std::cout << string_utils::to_string(flows) << "\n";
//                    std::cout << string_utils::to_string(branchesLimits) << "\n";
                    continue;
                }

                bestCost = flows[costIdx];
                bestValue = valueTableH[kv.first];
                bestValueDiff = kv.first - bestValue;
                bestFlow = flows;

//                std::cout << "bestValue = " << string_utils::to_string(bestValue) << "\n";
            }
        }

    }
    branchesFlows = bestFlow;
    cumulativeAgentCost += bestCost;

//    std::cout << "MW (this agent) : " << string_utils::to_string(bestValue)
//              << "\n MW (next agent): " << string_utils::to_string(bestValueDiff) << '\n';

    return std::make_tuple(bestValue, bestValueDiff);
}
