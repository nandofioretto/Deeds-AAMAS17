//
// Created by Ferdinando Fioretto on 11/3/15.
//

#ifndef D_AGC_DR_IDPOPSOLVER_H
#define D_AGC_DR_IDPOPSOLVER_H

#include <vector>
#include <map>

#include "IO/InputParams.h"
#include "Solver.h"
#include "IDPOPAgent.h"
#include "DPoperations.h"

using namespace misc_utils::string_utils;

class IDPOPSolver : public Solver {

public:
    typedef std::shared_ptr<IDPOPSolver> ptr;

    IDPOPSolver(Problem::ptr &P, InputParams::ptr inputs)
            : Solver(P->getHorizon()),  optHorizon(inputs->getOptHorizon()), discountFactor(P->getHorizon()),
              maxFlowPenaltyErr(inputs->getMaxFlowPenaltyErr()), nMaxSteps(inputs->getNMaxSteps()),
              wFlowPenalty(inputs->getWFlowPenalty()), flowCongestionLimit(inputs->getFlowCongestionLimit())
    {
        std::vector<std::pair<int,int>> powerLinesID;
        for (auto& flow : P->getPowerLines()) {
            auto p = std::make_pair(flow->getBusTopID(), flow->getBusZID());
            powerLinesID.push_back(p);
            branchesLimit.push_back(flow->getMax());
        }

        for (auto& kv : P->getPowerNetwork()) {
            auto& bus = kv.second;
            auto agent = std::make_shared<IDPOPAgent>(bus, powerLinesID, branchesLimit,
                                                      P->getHorizon(), P->getProbabilities(), optHorizon);
            agent->initialize();
            agents.push_back(agent);
        }
    }

    virtual void solve();

    std::string to_string() const {
        std::string ret;
        for (auto a : agents) {
            ret += a->to_string() + "\n";
        }
        return ret;
    }

private:
    void updateFlowPenaltyParams(double& alpha, double& prevAlpha, double& alphaUb, double& alphaLb,
                                 double& alphaErr, double& bestSatAlpha, bool isSat,
                                 cost_t& currUtil, cost_t& prevUtil, double& utilIncr);

private:
    std::vector<IDPOPAgent::ptr> agents;
    std::vector<double> branchesLimit;

    // Iterative parameter for each time-step
    int optHorizon;
    double discountFactor; // [0,1]
    // Parameters for the iteratve process
    double maxFlowPenaltyErr; // [0,1]
    int nMaxSteps;
    double wFlowPenalty, flowCongestionLimit; // [0,1] (m)
};

#endif //D_AGC_DR_IDPOPSOLVER_H