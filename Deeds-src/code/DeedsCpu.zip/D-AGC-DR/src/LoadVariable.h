//
// Created by Ferdinando Fioretto on 10/31/15.
//

#ifndef D_AGC_DR_LOADVARIABLE_H
#define D_AGC_DR_LOADVARIABLE_H


#include <string>
#include <vector>
#include <memory>

#include "Types.h"

class LoadVariable {

public:
    typedef std::shared_ptr<LoadVariable> ptr;

    LoadVariable(power_t predicted, const std::vector<power_t > &values, double alpha, double beta, double rampDelta)
            : value(-1), predicted(predicted), values(values), alpha(alpha), beta(beta), rampDelta(rampDelta) {
        std::sort(LoadVariable::values.begin(), LoadVariable::values.end());
        min = values.front();
        max = values.back();
    }

    power_t &operator[](std::size_t idx) {
        return values[idx];
    }

    const power_t &operator[](std::size_t idx) const {
        return values[idx];
    }

    cost_t getCostIdx(int valueIdx) {
        return getCost(values[valueIdx]);
    }

    cost_t getCost(power_t p) {
         return p * alpha + (beta * p * p);
//        return /*p <= (alpha / beta) ? */(p * alpha) - (0.5 * beta * p * p);
//                : (0.5 * p * p) / beta;
    }

    cost_t getCost() {
        return getCost(value);
    }


    power_t getMin() const {
        return min;
    }

    power_t getMax() const {
        return max;
    }

    power_t getPredicted() const {
        return predicted;
    }

    const std::vector<power_t> &getValues() const {
        return values;
    }

    double getRampDelta() const {
        return rampDelta;
    }

    void setPredicted(power_t predicted) {
        LoadVariable::predicted = predicted;
    }

    power_t getValue() const {
        return value;
    }

    void setValue(power_t value) {
        LoadVariable::value = value;
    }


    double getAlpha() const {
        return alpha;
    }

    double getBeta() const {
        return beta;
    }

    std::string to_string() const {
        std::string ret = "Load (" + std::to_string(alpha) + "," + std::to_string(beta) + ")";
        ret += " predicted: " + std::to_string(predicted) + " MW  range: [";
        for (power_t p : values)
            ret += std::to_string(p) + ",";
        ret += "]MW";
        ret += " ramp: (" + std::to_string(rampDelta) + ") MW";
        return ret;
    }

private:
    // Domain Info
    power_t min, max;
    power_t predicted;
    std::vector<power_t> values;
    power_t value; // selected value.

    // Parameters
    double alpha, beta;
    double rampDelta;
};


#endif //D_AGC_DR_LOADVARIABLE_H
