//
// Created by Ferdinando Fioretto on 11/9/15.
//

#ifndef D_AGC_DR_SANITYCHECK_H
#define D_AGC_DR_SANITYCHECK_H

#include <memory>
#include "Problem.h"

class SanityCheck {
public:
    typedef std::shared_ptr<SanityCheck> ptr;
    SanityCheck(Problem::ptr problem) {

    }

    void solve();
};


#endif //D_AGC_DR_SANITYCHECK_H
