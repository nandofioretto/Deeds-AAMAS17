//
// Created by Ferdinando Fioretto on 11/9/15.
//

#include <iostream>
#include "SanityCheck.h"

using namespace std;


void SanityCheck::solve() {
}

