#include <iostream>
#include <utils.hpp>
#include <Utils/Permutation.h>
#include <numeric>
#include <SanityCheck/SanityCheck.h>
#include <fstream>
#include <IO/InstanceGenerator.h>

#include "IO/InputParams.h"
#include "IDPOP/IDPOPSolver.h"
#include "Utils/Timer.h"


using namespace misc_utils::utils;
using namespace misc_utils::string_utils;

int main(int argc, char** argv) {
    auto inputs = std::make_shared<InputParams>(argc, argv);
    auto problem = std::make_shared<Problem>(inputs->getBusDataFileName(), inputs->getAcgDataFileName());

    double pw = 0, pi = 0;
    for (auto& kv : problem->getPowerNetwork()) {
        auto bus = kv.second;
        pw += bus->getInitialPowerWithdrawn();
        pi += bus->getInitialPowerInjected();
    }
    std::cout << "injected: " << pi << " withrawn: " << pw << "\n";

    //std::cout << inputs->to_string() << '\n';
    //std::cout << problem->to_string() << '\n';

    if (inputs->isCreatePDC()) {
        std::cout << "Creating PDC Matrix\n";
        std::ofstream ofs;
        ofs.open(inputs->getBusDataFileName() + "_f", std::ofstream::out);

        for (auto flow : problem->getPowerLines()) {
            ofs << flow->getBusTopID() + 1 << " " << flow->getBusZID() + 1 << " : ";
            for (auto d : flow->getShiftFactors())
                ofs << d << " ";
            ofs << "\n";
        }
        ofs.close();
    }
    if (inputs->isCreateData()) {
        InstanceGenerator generator(problem);
        for (int i=0; i<30; i++) {
            std::cout << "Creating Data " << i << "\n";

            generator.to_string(inputs->getAcgDataFileName());
        }
    }

    if (!inputs->isCreatePDC() && !inputs->isCreateData()) {
//        auto check = std::make_shared<SanityCheck>(problem);
//        check->solve();
        Timer<> wallclock;

        // Start Problem
        auto solver = std::make_shared<IDPOPSolver>(problem, inputs);
        wallclock.start();
        solver->solve();
            std::cout << "Global Time : " << wallclock.stopWatch() << " ms " << std::endl;
            std::cout << problem->printHorizonCosts() << std::endl;
    }
    return 0;
}